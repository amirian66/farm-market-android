#include "raylib.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdlib>
#include <fstream>
#include <string>
#if defined(__ANDROID__)
#include <jni.h>
#endif

#if defined(__ANDROID__)
static std::string g_androidSavePath = "farm_market_save.dat";
#endif

namespace {
// A compact directional-light shader gives every 3D primitive real volume.
// Raylib supplies the MVP matrix and vertex colours for its built-in shapes.
#if defined(__ANDROID__)
// Android uses OpenGL ES 2.0, so shaders must use GLSL ES 1.00 syntax.
const char* FARM_VERTEX_SHADER = R"GLSL(#version 100
attribute vec3 vertexPosition;
attribute vec2 vertexTexCoord;
attribute vec3 vertexNormal;
attribute vec4 vertexColor;
uniform mat4 mvp;
varying vec3 fragNormal;
varying vec4 fragColor;
void main() {
    fragNormal = normalize(vertexNormal);
    fragColor = vertexColor;
    gl_Position = mvp * vec4(vertexPosition, 1.0);
}
)GLSL";

const char* FARM_FRAGMENT_SHADER = R"GLSL(#version 100
precision mediump float;
varying vec3 fragNormal;
varying vec4 fragColor;
uniform vec3 lightDirection;
uniform vec3 viewDirection;
void main() {
    vec3 n = normalize(fragNormal);
    vec3 l = normalize(-lightDirection);
    vec3 v = normalize(viewDirection);
    float ndl = dot(n, l);
    float wrappedDiffuse = clamp((ndl + 0.30) / 1.30, 0.0, 1.0);
    float hemisphere = 0.10 + 0.16 * max(n.y, 0.0);
    float lighting = clamp(0.58 + 0.58 * wrappedDiffuse + hemisphere, 0.58, 1.22);
    vec3 halfVector = normalize(l + v);
    float specular = pow(max(dot(n, halfVector), 0.0), 28.0) * 0.12;
    float rim = pow(1.0 - max(dot(n, v), 0.0), 3.0) * 0.055;
    vec3 warmLight = vec3(1.0, 0.91, 0.78);
    vec3 base = fragColor.rgb;
    vec3 lit = base * lighting + warmLight * specular + vec3(0.20, 0.29, 0.34) * rim;
    float haze = smoothstep(0.972, 0.999, gl_FragCoord.z);
    vec3 hazeColour = vec3(0.72, 0.83, 0.86);
    gl_FragColor = vec4(mix(lit, hazeColour, haze * 0.28), fragColor.a);
}
)GLSL";
#else
const char* FARM_VERTEX_SHADER = R"GLSL(#version 330
in vec3 vertexPosition;
in vec2 vertexTexCoord;
in vec3 vertexNormal;
in vec4 vertexColor;
uniform mat4 mvp;
out vec3 fragNormal;
out vec4 fragColor;
void main() {
    fragNormal = normalize(vertexNormal);
    fragColor = vertexColor;
    gl_Position = mvp * vec4(vertexPosition, 1.0);
}
)GLSL";

const char* FARM_FRAGMENT_SHADER = R"GLSL(#version 330
in vec3 fragNormal;
in vec4 fragColor;
uniform vec3 lightDirection;
uniform vec3 viewDirection;
out vec4 finalColor;
void main() {
    vec3 n = normalize(fragNormal);
    vec3 l = normalize(-lightDirection);
    vec3 v = normalize(viewDirection);
    float ndl = dot(n, l);
    float wrappedDiffuse = clamp((ndl + 0.30) / 1.30, 0.0, 1.0);
    float hemisphere = 0.10 + 0.16 * max(n.y, 0.0);
    float lighting = clamp(0.58 + 0.58 * wrappedDiffuse + hemisphere, 0.58, 1.22);
    vec3 halfVector = normalize(l + v);
    float specular = pow(max(dot(n, halfVector), 0.0), 28.0) * 0.12;
    float rim = pow(1.0 - max(dot(n, v), 0.0), 3.0) * 0.055;
    vec3 warmLight = vec3(1.0, 0.91, 0.78);
    vec3 base = fragColor.rgb;
    vec3 lit = base * lighting + warmLight * specular + vec3(0.20, 0.29, 0.34) * rim;
    float haze = smoothstep(0.972, 0.999, gl_FragCoord.z);
    vec3 hazeColour = vec3(0.72, 0.83, 0.86);
    finalColor = vec4(mix(lit, hazeColour, haze * 0.28), fragColor.a);
}
)GLSL";

#endif

constexpr int SCREEN_W = 1440;
constexpr int SCREEN_H = 900;
constexpr float PLAYER_SPEED = 5.2f;
constexpr float FIELD_RADIUS = 2.65f;
constexpr float MARKET_RADIUS = 4.25f;
constexpr int MAX_FIELD_CROPS = 15;
constexpr float CROP_STAGE_SECONDS = 5.0f;
constexpr int SEED_PACK_SIZE = 5;
constexpr int SEED_PACK_PRICE = 24;
constexpr int MAX_STALL_UPGRADE = 3;

struct CropInfo {
    const char* name;
    int price;
    Color main;
    Color leaf;
};

constexpr std::array<CropInfo, 3> CROPS{{
    {"Carrot", 5, {238, 125, 43, 255}, {62, 153, 74, 255}},
    {"Apple", 8, {203, 58, 55, 255}, {65, 145, 68, 255}},
    {"Pumpkin", 12, {239, 150, 48, 255}, {61, 139, 66, 255}}
}};

struct CropField {
    Vector3 center{};
    int cropType = 0;
    std::array<int, MAX_FIELD_CROPS> stage{};       // 0 empty, 1 seedling, 2 growing, 3 ripe
    std::array<float, MAX_FIELD_CROPS> growth{};    // progress toward the next stage
    std::array<float, MAX_FIELD_CROPS> wetTimer{};  // watered plots grow faster
};

CropField MakeField(Vector3 center, int cropType) {
    CropField field{};
    field.center = center;
    field.cropType = cropType;
    field.stage.fill(3); // Start with a ready-to-harvest crop in every plot.
    return field;
}

bool SaveGame(const std::string& path, int coins, int served, int upgrade,
              const std::array<int, 3>& inventory, const std::array<int, 3>& seeds,
              const std::array<CropField, 3>& fields) {
    std::ofstream out(path);
    if (!out) return false;
    out << "LFM_SAVE 1\n" << coins << ' ' << served << ' ' << upgrade << '\n';
    for (int value : inventory) out << value << ' ';
    out << '\n';
    for (int value : seeds) out << value << ' ';
    out << '\n';
    for (const auto& field : fields) {
        out << field.cropType << '\n';
        for (int i = 0; i < MAX_FIELD_CROPS; ++i) {
            out << field.stage[i] << ' ' << field.growth[i] << ' ' << field.wetTimer[i] << '\n';
        }
    }
    return static_cast<bool>(out);
}

bool LoadGame(const std::string& path, int& coins, int& served, int& upgrade,
              std::array<int, 3>& inventory, std::array<int, 3>& seeds,
              std::array<CropField, 3>& fields) {
    std::ifstream in(path);
    if (!in) return false;
    std::string magic;
    int version = 0;
    int loadedCoins = 0, loadedServed = 0, loadedUpgrade = 0;
    if (!(in >> magic >> version >> loadedCoins >> loadedServed >> loadedUpgrade) ||
        magic != "LFM_SAVE" || version != 1 || loadedCoins < 0 || loadedServed < 0 ||
        loadedUpgrade < 0 || loadedUpgrade > MAX_STALL_UPGRADE) return false;

    std::array<int, 3> loadedInventory{};
    std::array<int, 3> loadedSeeds{};
    for (int& value : loadedInventory) {
        if (!(in >> value) || value < 0 || value > 9999) return false;
    }
    for (int& value : loadedSeeds) {
        if (!(in >> value) || value < 0 || value > 9999) return false;
    }

    auto loadedFields = fields;
    for (auto& field : loadedFields) {
        int cropType = -1;
        if (!(in >> cropType) || cropType != field.cropType) return false;
        for (int i = 0; i < MAX_FIELD_CROPS; ++i) {
            int stage = 0;
            float growth = 0.0f;
            float wet = 0.0f;
            if (!(in >> stage >> growth >> wet) || stage < 0 || stage > 3 ||
                !std::isfinite(growth) || !std::isfinite(wet) ||
                growth < 0.0f || growth > CROP_STAGE_SECONDS || wet < 0.0f || wet > 30.0f) {
                return false;
            }
            field.stage[i] = stage;
            field.growth[i] = growth;
            field.wetTimer[i] = wet;
        }
    }

    coins = loadedCoins;
    served = loadedServed;
    upgrade = loadedUpgrade;
    inventory = loadedInventory;
    seeds = loadedSeeds;
    fields = loadedFields;
    return true;
}

struct Customer {
    bool active = true;
    int order = 0;
    float patience = 38.0f;
    float maxPatience = 38.0f;
    float spawnTimer = 0.0f;
    float idleTime = 0.0f;
    Color shirt = {76, 136, 190, 255};
    Color pants = {63, 76, 112, 255};
};

struct Message {
    std::string text;
    float timer = 0.0f;
    Color color = WHITE;
};

struct Particle {
    Vector3 position{};
    Vector3 velocity{};
    float life = 0.0f;
    float maxLife = 0.0f;
    Color color = WHITE;
};

float Clamp(float value, float low, float high) {
    return std::max(low, std::min(value, high));
}

float DistanceXZ(Vector3 a, Vector3 b) {
    const float dx = a.x - b.x;
    const float dz = a.z - b.z;
    return std::sqrt(dx * dx + dz * dz);
}

Vector3 V3(float x, float y, float z) { return {x, y, z}; }

Color WithAlpha(Color c, unsigned char alpha) {
    c.a = alpha;
    return c;
}

void Say(Message& message, const std::string& text, Color color = WHITE) {
    message.text = text;
    message.timer = 2.7f;
    message.color = color;
}

void DrawShadow(Vector3 p, float radiusX, float radiusZ, unsigned char alpha = 70) {
    DrawCylinder(V3(p.x, 0.035f, p.z), radiusX, radiusX, 0.035f, 20,
                 WithAlpha({35, 47, 34, 255}, alpha));
    // A smaller dark shape makes the contact shadow look softer.
    DrawCylinder(V3(p.x, 0.056f, p.z), radiusX * 0.72f, radiusZ, 0.012f, 20,
                 WithAlpha({34, 42, 30, 255}, static_cast<unsigned char>(alpha * 0.45f)));
}

float Hash01(int n) {
    // Stable pseudo-random values keep the landscape art consistent between frames.
    unsigned int x = static_cast<unsigned int>(n);
    x ^= x >> 16;
    x *= 0x7feb352du;
    x ^= x >> 15;
    x *= 0x846ca68bu;
    x ^= x >> 16;
    return static_cast<float>(x & 0x00ffffffu) / 16777215.0f;
}

void DrawGrassTuft(float x, float z, float scale, float phase, bool flowering = false) {
    const Color greens[] = {
        {59, 132, 66, 255}, {78, 153, 72, 255}, {104, 174, 81, 255}
    };
    const float baseY = 0.045f;
    for (int blade = 0; blade < 4; ++blade) {
        const float angle = phase + blade * 1.5708f;
        const float h = scale * (0.25f + 0.12f * Hash01(blade + static_cast<int>(x * 31.0f)));
        const Vector3 tip = V3(x + std::cos(angle) * h * 0.56f,
                               baseY + h, z + std::sin(angle) * h * 0.56f);
        DrawCylinderEx(V3(x, baseY, z), tip, 0.035f * scale, 0.004f, 5,
                       greens[blade % 3]);
    }
    if (flowering) {
        const Color petalColor = Hash01(static_cast<int>((x + z) * 100.0f)) > 0.5f
            ? Color{255, 223, 126, 255} : Color{248, 190, 207, 255};
        const float fy = baseY + scale * 0.56f;
        DrawCylinder(V3(x, fy - 0.11f, z), 0.012f, 0.012f, 0.22f, 5,
                     {62, 132, 64, 255});
        for (int petalIndex = 0; petalIndex < 4; ++petalIndex) {
            const float a = petalIndex * 1.5708f;
            DrawSphere(V3(x + std::cos(a) * 0.075f * scale, fy,
                          z + std::sin(a) * 0.075f * scale),
                       0.055f * scale, petalColor);
        }
        DrawSphere(V3(x, fy + 0.012f, z), 0.045f * scale, {190, 126, 48, 255});
    }
}

void DrawRock(Vector3 p, float size, Color color) {
    DrawSphere(V3(p.x, p.y + size * 0.34f, p.z), size, color);
    DrawSphere(V3(p.x + size * 0.53f, p.y + size * 0.26f, p.z - size * 0.18f),
               size * 0.66f, {color.r, color.g, color.b, color.a});
}

void DrawWindmill(Vector3 p, float time) {
    DrawShadow(p, 0.9f, 0.8f, 55);
    DrawCylinder(V3(p.x, 1.45f, p.z), 0.50f, 0.72f, 2.9f, 9,
                 {222, 208, 169, 255});
    DrawCylinder(V3(p.x, 2.93f, p.z), 0.57f, 0.57f, 0.16f, 9,
                 {160, 96, 60, 255});
    DrawCylinder(V3(p.x, 3.12f, p.z), 0.32f, 0.42f, 0.27f, 9,
                 {153, 79, 59, 255});
    const float angle = time * 0.75f;
    const Vector3 hub = V3(p.x, 3.45f, p.z + 0.54f);
    DrawSphere(hub, 0.18f, {115, 73, 49, 255});
    for (int i = 0; i < 4; ++i) {
        const float a = angle + i * 1.5708f;
        const float dx = std::cos(a);
        const float dy = std::sin(a);
        const Vector3 tip = V3(hub.x + dx * 1.55f, hub.y + dy * 1.55f, hub.z);
        DrawCylinderEx(hub, tip, 0.085f, 0.025f, 7, {231, 221, 195, 255});
        const Vector3 paddle = V3(hub.x + dx * 1.10f - dy * 0.20f,
                                  hub.y + dy * 1.10f + dx * 0.20f, hub.z + 0.025f);
        DrawCylinderEx(paddle, tip, 0.055f, 0.018f, 6, {188, 83, 64, 255});
        DrawSphere(V3(tip.x, tip.y, tip.z), 0.055f, {255, 236, 191, 255});
    }
}

void DrawLantern(Vector3 p, float glow) {
    DrawCylinderEx(V3(p.x, p.y + 0.40f, p.z), V3(p.x, p.y + 0.70f, p.z),
                   0.025f, 0.025f, 6, {83, 62, 45, 255});
    DrawCubeV(V3(p.x, p.y + 0.18f, p.z), V3(0.32f, 0.40f, 0.32f),
              {93, 66, 49, 255});
    DrawCubeV(V3(p.x, p.y + 0.18f, p.z), V3(0.21f, 0.29f, 0.21f),
              {255, 222, 139, 255});
    DrawCubeV(V3(p.x, p.y + 0.42f, p.z), V3(0.35f, 0.06f, 0.35f),
              {74, 55, 44, 255});
    DrawSphere(V3(p.x, p.y + 0.20f, p.z), 0.12f,
               WithAlpha({255, 229, 160, 255}, static_cast<unsigned char>(glow)));
}

void DrawBench(Vector3 p) {
    for (int i = 0; i < 3; ++i) {
        DrawCubeV(V3(p.x, 0.72f, p.z - 0.17f + i * 0.17f),
                  V3(1.65f, 0.13f, 0.15f), {172, 112, 67, 255});
    }
    for (float x : {p.x - 0.62f, p.x + 0.62f}) {
        DrawCubeV(V3(x, 0.38f, p.z), V3(0.13f, 0.72f, 0.14f), {103, 69, 47, 255});
        DrawCubeV(V3(x, 1.04f, p.z - 0.32f), V3(0.13f, 0.78f, 0.13f), {103, 69, 47, 255});
    }
    DrawCubeV(V3(p.x, 1.25f, p.z - 0.32f), V3(1.55f, 0.12f, 0.13f),
              {178, 120, 73, 255});
}

void DrawFlowerPot(Vector3 p, float scale, float time) {
    DrawCylinder(V3(p.x, 0.22f * scale, p.z), 0.25f * scale, 0.34f * scale,
                 0.42f * scale, 10, {184, 105, 70, 255});
    DrawCylinder(V3(p.x, 0.44f * scale, p.z), 0.34f * scale, 0.34f * scale,
                 0.07f * scale, 10, {215, 142, 92, 255});
    for (int i = 0; i < 3; ++i) {
        const float a = i * 2.094f + time * 0.12f;
        const Vector3 end = V3(p.x + std::cos(a) * 0.27f * scale,
                               0.93f * scale, p.z + std::sin(a) * 0.27f * scale);
        DrawCylinderEx(V3(p.x, 0.46f * scale, p.z), end, 0.025f * scale,
                       0.008f, 5, {64, 142, 71, 255});
        DrawSphere(end, 0.12f * scale,
                   i == 0 ? Color{238, 101, 116, 255} :
                   (i == 1 ? Color{255, 218, 112, 255} : Color{170, 143, 224, 255}));
    }
}

void DrawTree(Vector3 p, float scale, float time, bool hasFruit = false) {
    DrawShadow(p, 0.78f * scale, 0.64f * scale, 52);
    DrawCylinder(V3(p.x, 1.0f * scale, p.z), 0.22f * scale, 0.29f * scale,
                 1.95f * scale, 10, {117, 76, 47, 255});
    DrawCylinderEx(V3(p.x, 0.95f * scale, p.z),
                   V3(p.x - 0.55f * scale, 2.0f * scale, p.z + 0.12f * scale),
                   0.12f * scale, 0.075f * scale, 8, {126, 83, 49, 255});
    DrawCylinderEx(V3(p.x, 1.15f * scale, p.z),
                   V3(p.x + 0.5f * scale, 2.05f * scale, p.z - 0.15f * scale),
                   0.11f * scale, 0.065f * scale, 8, {126, 83, 49, 255});

    const Color green1 = {57, 137, 68, 255};
    const Color green2 = {75, 157, 77, 255};
    const Color green3 = {91, 174, 89, 255};
    DrawSphere(V3(p.x, 2.48f * scale, p.z), 0.92f * scale, green1);
    DrawSphere(V3(p.x - 0.58f * scale, 2.25f * scale, p.z + 0.04f * scale),
               0.66f * scale, green2);
    DrawSphere(V3(p.x + 0.60f * scale, 2.30f * scale, p.z - 0.08f * scale),
               0.68f * scale, green2);
    DrawSphere(V3(p.x - 0.12f * scale, 2.95f * scale, p.z - 0.08f * scale),
               0.61f * scale, green3);
    DrawSphere(V3(p.x + 0.22f * scale, 2.65f * scale, p.z + 0.45f * scale),
               0.52f * scale, green3);
    // Smaller leaf clusters break the simple round silhouette and catch the light.
    DrawSphere(V3(p.x - 0.28f * scale, 2.72f * scale, p.z - 0.47f * scale),
               0.39f * scale, {105, 184, 91, 255});
    DrawSphere(V3(p.x + 0.48f * scale, 2.82f * scale, p.z + 0.10f * scale),
               0.36f * scale, {66, 146, 70, 255});
    DrawSphere(V3(p.x - 0.68f * scale, 2.48f * scale, p.z - 0.20f * scale),
               0.31f * scale, {86, 163, 77, 255});
    // Small overlapping leaf crowns break the large spheres into a richer canopy.
    for (int leaf = 0; leaf < 12; ++leaf) {
        const float a = leaf * 2.39996f;
        const float ring = 0.48f + 0.10f * (leaf % 3);
        const float y = 2.38f + 0.18f * (leaf % 4);
        const Color leafTone = (leaf % 3 == 0) ? Color{113, 188, 91, 255} :
                               ((leaf % 3 == 1) ? Color{67, 148, 72, 255} : Color{88, 166, 79, 255});
        DrawSphere(V3(p.x + std::cos(a) * ring * scale, y * scale,
                      p.z + std::sin(a) * ring * scale), 0.24f * scale, leafTone);
    }

    if (hasFruit) {
        const float sway = std::sin(time * 1.5f + p.x) * 0.06f;
        for (int i = 0; i < 5; ++i) {
            const float ox = ((i % 3) - 1) * 0.34f * scale;
            const float oz = (i % 2 == 0 ? 0.34f : -0.24f) * scale;
            const float oy = (2.45f + (i % 3) * 0.2f) * scale + sway;
            DrawSphere(V3(p.x + ox, oy, p.z + oz), 0.13f * scale,
                       i % 2 ? Color{207, 53, 48, 255} : Color{229, 78, 54, 255});
        }
    }
}

void DrawCropPlant(Vector3 p, int type, float time, int seed, int stage = 3) {
    if (stage <= 0) return;
    if (stage == 1) {
        const float swaySmall = std::sin(time * 2.5f + seed) * 0.018f;
        DrawCylinder(V3(p.x, 0.17f, p.z), 0.035f, 0.018f, 0.30f, 7,
                     {83, 132, 64, 255});
        DrawSphere(V3(p.x - 0.10f + swaySmall, 0.30f, p.z), 0.12f,
                   {94, 164, 77, 255});
        DrawSphere(V3(p.x + 0.10f - swaySmall, 0.34f, p.z + 0.04f), 0.12f,
                   {111, 180, 83, 255});
        return;
    }
    if (stage == 2) {
        const float swayMedium = std::sin(time * 2.0f + seed * 0.7f) * 0.025f;
        DrawCylinder(V3(p.x, 0.22f, p.z), 0.07f, 0.025f, 0.43f, 8,
                     type == 1 ? Color{120, 85, 55, 255} : Color{83, 132, 64, 255});
        for (int leaf = 0; leaf < 5; ++leaf) {
            const float a = leaf * 1.2566f + seed;
            DrawSphere(V3(p.x + std::cos(a) * 0.22f + swayMedium, 0.42f + 0.07f * (leaf % 2),
                          p.z + std::sin(a) * 0.22f), 0.16f,
                       leaf % 2 ? Color{83, 157, 76, 255} : Color{105, 177, 82, 255});
        }
        if (type == 2) DrawSphere(V3(p.x, 0.38f, p.z), 0.17f, {217, 129, 48, 255});
        if (type == 1) DrawSphere(V3(p.x + 0.08f, 0.57f, p.z + 0.06f), 0.08f,
                                  {216, 81, 61, 255});
        return;
    }
    const float sway = std::sin(time * 2.0f + seed * 0.7f) * 0.035f;
    if (type == 0) { // Carrot tops and orange roots.
        DrawCylinder(V3(p.x, 0.20f, p.z), 0.14f, 0.018f, 0.38f, 10, CROPS[0].main);
        DrawSphere(V3(p.x, 0.36f, p.z), 0.105f, {248, 151, 55, 255});
        DrawCylinderEx(V3(p.x, 0.37f, p.z), V3(p.x + sway, 0.68f, p.z),
                       0.035f, 0.018f, 6, CROPS[0].leaf);
        for (int i = 0; i < 7; ++i) {
            const float a = i * 0.8976f + seed;
            const Vector3 end = V3(p.x + std::cos(a) * (0.25f + 0.035f * (i % 2)),
                                   0.54f + (i % 3) * 0.075f,
                                   p.z + std::sin(a) * (0.25f + 0.035f * (i % 2)));
            DrawCylinderEx(V3(p.x, 0.48f, p.z), end, 0.052f, 0.008f, 6,
                           i % 2 ? Color{61, 153, 73, 255} : Color{87, 177, 83, 255});
        }
        DrawSphere(V3(p.x - 0.13f, 0.49f, p.z + 0.11f), 0.075f, {112, 185, 79, 255});
    } else if (type == 1) { // Small apple tree.
        DrawCylinder(V3(p.x, 0.40f, p.z), 0.075f, 0.10f, 0.70f, 8, {125, 83, 48, 255});
        DrawSphere(V3(p.x, 0.86f + sway, p.z), 0.37f, CROPS[1].leaf);
        DrawSphere(V3(p.x - 0.23f, 0.76f, p.z + 0.06f), 0.25f, {80, 160, 79, 255});
        DrawSphere(V3(p.x + 0.21f, 0.78f, p.z - 0.08f), 0.25f, {72, 150, 72, 255});
        DrawSphere(V3(p.x - 0.14f, 0.87f, p.z + 0.27f), 0.105f, CROPS[1].main);
        DrawSphere(V3(p.x + 0.17f, 0.70f, p.z - 0.22f), 0.105f, {222, 75, 57, 255});
        DrawSphere(V3(p.x + 0.08f, 1.06f, p.z + 0.08f), 0.09f, {215, 64, 52, 255});
        DrawSphere(V3(p.x - 0.25f, 1.02f, p.z - 0.20f), 0.075f, {236, 91, 63, 255});
        DrawSphere(V3(p.x + 0.25f, 0.95f, p.z + 0.16f), 0.07f, {240, 111, 66, 255});
        DrawSphere(V3(p.x - 0.04f, 1.20f, p.z - 0.20f), 0.12f, {94, 174, 83, 255});
    } else { // Pumpkin vines and fruit.
        DrawCylinderEx(V3(p.x - 0.34f, 0.12f, p.z), V3(p.x + 0.34f, 0.15f, p.z + 0.05f),
                       0.035f, 0.035f, 6, CROPS[2].leaf);
        DrawSphere(V3(p.x, 0.42f, p.z), 0.34f, CROPS[2].main);
        DrawSphere(V3(p.x - 0.12f, 0.42f, p.z), 0.24f, {249, 171, 64, 255});
        DrawSphere(V3(p.x + 0.13f, 0.42f, p.z), 0.23f, {213, 119, 38, 255});
        for (int rib = 0; rib < 6; ++rib) {
            const float a = rib * 1.0472f;
            DrawSphere(V3(p.x + std::cos(a) * 0.22f, 0.43f,
                          p.z + std::sin(a) * 0.22f), 0.105f,
                       rib % 2 ? Color{255, 177, 72, 255} : Color{225, 126, 39, 255});
        }
        DrawCylinder(V3(p.x, 0.70f, p.z), 0.035f, 0.055f, 0.16f, 6, {69, 125, 55, 255});
        DrawSphere(V3(p.x - 0.27f, 0.20f, p.z + 0.2f), 0.11f, CROPS[2].leaf);
        DrawSphere(V3(p.x + 0.26f, 0.19f, p.z - 0.18f), 0.12f, {81, 157, 69, 255});
    }
}

void DrawField(const CropField& field, float time, int index) {
    const float w = 4.7f;
    const float d = 3.35f;
    DrawCubeV(V3(field.center.x, 0.12f, field.center.z), V3(w + 0.35f, 0.24f, d + 0.35f),
              {104, 69, 43, 255});
    DrawCubeV(V3(field.center.x, 0.245f, field.center.z), V3(w, 0.12f, d),
              {143, 96, 57, 255});

    for (int row = 0; row < 3; ++row) {
        const float z = field.center.z - 1.03f + row * 1.03f;
        DrawCubeV(V3(field.center.x, 0.32f, z), V3(4.38f, 0.055f, 0.58f),
                  {111, 72, 43, 255});
        DrawCubeV(V3(field.center.x, 0.355f, z + 0.28f), V3(4.32f, 0.025f, 0.07f),
                  {184, 130, 78, 255});
    }

    for (int i = 0; i < MAX_FIELD_CROPS; ++i) {
        const int row = i / 5;
        const int col = i % 5;
        const float x = field.center.x - 1.68f + col * 0.83f;
        const float z = field.center.z - 1.03f + row * 1.03f;
        // Empty plots show rich, freshly tilled soil; growing plots visibly change shape.
        if (field.stage[i] == 0) {
            DrawCubeV(V3(x, 0.385f, z), V3(0.42f, 0.025f, 0.34f),
                      {93, 61, 39, 255});
            DrawSphere(V3(x - 0.12f, 0.405f, z + 0.04f), 0.025f,
                       {163, 123, 76, 255});
        } else {
            DrawCropPlant(V3(x, 0.38f, z), field.cropType, time, i + index * 17,
                          field.stage[i]);
        }
        if (field.wetTimer[i] > 0.0f && field.stage[i] > 0 && field.stage[i] < 3) {
            DrawSphere(V3(x + 0.19f, 0.43f, z - 0.13f), 0.035f,
                       {106, 190, 218, 230});
        }
    }

    // Corner stakes make each crop bed read as a real plot.
    for (int sx : {-1, 1}) {
        for (int sz : {-1, 1}) {
            DrawCubeV(V3(field.center.x + sx * 2.31f, 0.38f,
                         field.center.z + sz * 1.62f), V3(0.12f, 0.5f, 0.12f),
                      {190, 142, 91, 255});
        }
    }
}

Vector3 PersonPoint(Vector3 origin, float x, float y, float z, float yaw) {
    const float c = std::cos(yaw);
    const float sn = std::sin(yaw);
    return V3(origin.x + x * c + z * sn, y, origin.z - x * sn + z * c);
}

void DrawPerson(Vector3 p, float yaw, Color shirt, Color pants, bool farmer, float walkPhase) {
    DrawShadow(p, 0.43f, 0.36f, 82);
    const float bob = std::sin(walkPhase * 8.0f) * 0.035f;
    const float stride = std::sin(walkPhase * 8.0f);
    const float legSwing = stride * 0.15f;
    const Color skin = {241, 194, 155, 255};
    const Color boot = {75, 57, 46, 255};
    auto pt = [&](float x, float y, float z) {
        return PersonPoint(p, x, y + bob, z, yaw);
    };
    auto joint = [&](float x, float y, float z, float r, Color color) {
        DrawSphere(pt(x, y, z), r, color);
    };
    auto limb = [&](Vector3 a, Vector3 b, float r1, float r2, Color color) {
        DrawCylinderEx(a, b, r1, r2, 10, color);
    };

    // Soft contact shadow and rounded shoes.
    joint(-0.17f, 0.12f, 0.11f + legSwing * 0.38f, 0.18f, boot);
    joint( 0.17f, 0.12f, 0.11f - legSwing * 0.38f, 0.18f, boot);
    DrawCubeV(pt(-0.17f, 0.13f, 0.20f + legSwing * 0.38f),
              V3(0.26f, 0.11f, 0.28f), {103, 78, 58, 255});
    DrawCubeV(pt( 0.17f, 0.13f, 0.20f - legSwing * 0.38f),
              V3(0.26f, 0.11f, 0.28f), {103, 78, 58, 255});

    // Legs use tapered segments and round joints instead of hard rectangular blocks.
    Vector3 leftHip = pt(-0.17f, 0.77f, 0.0f);
    Vector3 leftKnee = pt(-0.18f, 0.43f, legSwing * 0.48f);
    Vector3 leftAnkle = pt(-0.17f, 0.19f, legSwing * 0.68f);
    Vector3 rightHip = pt(0.17f, 0.77f, 0.0f);
    Vector3 rightKnee = pt(0.18f, 0.43f, -legSwing * 0.48f);
    Vector3 rightAnkle = pt(0.17f, 0.19f, -legSwing * 0.68f);
    limb(leftHip, leftKnee, 0.135f, 0.105f, pants);
    limb(leftKnee, leftAnkle, 0.105f, 0.085f, pants);
    limb(rightHip, rightKnee, 0.135f, 0.105f, pants);
    limb(rightKnee, rightAnkle, 0.105f, 0.085f, pants);
    joint(-0.18f, 0.43f, legSwing * 0.48f, 0.115f, pants);
    joint(0.18f, 0.43f, -legSwing * 0.48f, 0.115f, pants);

    // Torso: overlapping rounded forms give the character a smoother silhouette.
    limb(pt(0.0f, 0.72f, 0.0f), pt(0.0f, 1.36f, 0.0f), 0.31f, 0.36f, shirt);
    joint(0.0f, 1.28f, 0.0f, 0.34f, shirt);
    joint(0.0f, 0.87f, 0.0f, 0.29f, shirt);
    joint(-0.36f, 1.26f, 0.0f, 0.16f, shirt);
    joint(0.36f, 1.26f, 0.0f, 0.16f, shirt);

    // Animated arms swing while walking. Idle customers gently move their hands.
    const float armSwing = farmer ? stride * 0.17f : std::sin(walkPhase * 1.8f) * 0.045f;
    Vector3 lShoulder = pt(-0.36f, 1.30f, 0.0f);
    Vector3 lElbow = pt(-0.48f, 0.99f, 0.08f + armSwing);
    Vector3 lHand = pt(-0.43f, 0.73f, 0.15f + armSwing * 1.45f);
    Vector3 rShoulder = pt(0.36f, 1.30f, 0.0f);
    Vector3 rElbow = pt(0.48f, 0.99f, 0.08f - armSwing);
    Vector3 rHand = pt(0.43f, 0.73f, 0.15f - armSwing * 1.45f);
    limb(lShoulder, lElbow, 0.12f, 0.095f, shirt);
    limb(lElbow, lHand, 0.095f, 0.078f, shirt);
    limb(rShoulder, rElbow, 0.12f, 0.095f, shirt);
    limb(rElbow, rHand, 0.095f, 0.078f, shirt);
    DrawSphere(lHand, 0.105f, skin);
    DrawSphere(rHand, 0.105f, skin);

    // Small apron, seams and buttons on the farmer.
    if (farmer) {
        DrawCubeV(pt(0.0f, 1.03f, 0.285f), V3(0.40f, 0.51f, 0.075f), {56, 126, 83, 255});
        DrawCubeV(pt(0.0f, 1.27f, 0.31f), V3(0.42f, 0.07f, 0.06f), {218, 197, 142, 255});
        for (int button = 0; button < 3; ++button) {
            DrawSphere(pt(0.0f, 1.16f - button * 0.12f, 0.34f), 0.026f,
                       {247, 221, 160, 255});
        }
        DrawCubeV(pt(-0.19f, 1.25f, 0.12f), V3(0.065f, 0.42f, 0.055f),
                  {230, 215, 177, 255});
        DrawCubeV(pt(0.19f, 1.25f, 0.12f), V3(0.065f, 0.42f, 0.055f),
                  {230, 215, 177, 255});
    }

    // Neck and head with cheek, ear, nose and eye details.
    limb(pt(0.0f, 1.36f, 0.0f), pt(0.0f, 1.55f, 0.02f), 0.13f, 0.13f, skin);
    joint(0.0f, 1.75f, 0.015f, 0.285f, skin);
    joint(-0.255f, 1.74f, 0.005f, 0.075f, skin);
    joint(0.255f, 1.74f, 0.005f, 0.075f, skin);
    joint(0.0f, 1.67f, 0.257f, 0.07f, {230, 165, 132, 255});
    const bool blink = std::fmod(std::max(0.0f, walkPhase), 4.2f) > 4.05f;
    const float eyeY = blink ? 1.755f : 1.79f;
    DrawSphere(pt(-0.095f, eyeY, 0.254f), blink ? 0.012f : 0.027f, {48, 43, 39, 255});
    DrawSphere(pt(0.095f, eyeY, 0.254f), blink ? 0.012f : 0.027f, {48, 43, 39, 255});
    DrawSphere(pt(-0.105f, 1.81f, 0.276f), 0.010f, WHITE);
    DrawSphere(pt(0.085f, 1.81f, 0.276f), 0.010f, WHITE);
    limb(pt(-0.06f, 1.59f, 0.265f), pt(0.06f, 1.59f, 0.265f), 0.012f, 0.012f,
         {145, 77, 69, 255});

    // Hair cap and side locks.
    DrawSphere(pt(0.0f, 1.93f, -0.005f), 0.235f,
               farmer ? Color{96, 62, 39, 255} : Color{91, 61, 48, 255});
    joint(-0.21f, 1.80f, -0.005f, 0.105f, {91, 61, 48, 255});
    joint(0.21f, 1.80f, -0.005f, 0.105f, {91, 61, 48, 255});

    if (farmer) {
        // Wide straw hat with a dark fabric band and a small leaf decoration.
        DrawCylinder(pt(0.0f, 2.015f, 0.0f), 0.43f, 0.43f, 0.075f, 20,
                     {232, 193, 116, 255});
        DrawCylinder(pt(0.0f, 2.12f, 0.0f), 0.255f, 0.285f, 0.20f, 16,
                     {238, 205, 137, 255});
        DrawCylinder(pt(0.0f, 2.065f, 0.0f), 0.285f, 0.285f, 0.035f, 16,
                     {104, 144, 79, 255});
        DrawSphere(pt(0.23f, 2.10f, 0.04f), 0.075f, {78, 155, 80, 255});
    } else if (Hash01(static_cast<int>(walkPhase * 100.0f)) > 0.50f) {
        // A simple headscarf gives some customers a distinct silhouette.
        DrawCylinder(pt(0.0f, 1.99f, 0.0f), 0.30f, 0.30f, 0.07f, 14,
                     {186, 91, 92, 255});
    }
}

void DrawMarketStall(float time, int upgradeLevel) {
    const float cx = 6.4f;
    const float cz = -2.4f;
    DrawShadow(V3(cx, 0, cz + 1.1f), 3.4f, 2.4f, 50);

    // Wooden floor and back wall.
    DrawCubeV(V3(cx, 0.18f, cz), V3(5.8f, 0.32f, 4.1f), {125, 83, 50, 255});
    DrawCubeV(V3(cx, 1.45f, cz - 1.82f), V3(5.4f, 2.55f, 0.2f), {224, 195, 148, 255});
    for (int i = 0; i < 9; ++i) {
        const float x = cx - 2.45f + i * 0.61f;
        DrawCubeV(V3(x, 1.45f, cz - 1.69f), V3(0.035f, 2.35f, 0.025f),
                  {184, 145, 99, 255});
    }

    // Posts and roof beams.
    for (float x : {cx - 2.75f, cx + 2.75f}) {
        for (float z : {cz - 1.75f, cz + 1.35f}) {
            DrawCubeV(V3(x, 1.65f, z), V3(0.22f, 3.1f, 0.22f), {119, 73, 43, 255});
            DrawCubeV(V3(x, 3.25f, z), V3(0.31f, 0.14f, 0.31f), {159, 104, 61, 255});
        }
    }
    DrawCubeV(V3(cx, 3.13f, cz - 1.75f), V3(5.75f, 0.22f, 0.22f), {120, 76, 46, 255});
    DrawCubeV(V3(cx, 3.13f, cz + 1.35f), V3(5.75f, 0.22f, 0.22f), {120, 76, 46, 255});

    // Striped canopy: alternating red and cream boards.
    for (int i = 0; i < 10; ++i) {
        const float x = cx - 2.72f + i * 0.605f;
        const Color awning = i % 2 == 0 ? Color{190, 69, 57, 255} : Color{246, 229, 193, 255};
        DrawCubeV(V3(x, 3.38f, cz - 0.18f), V3(0.59f, 0.16f, 3.55f), awning);
        DrawCubeV(V3(x, 3.22f, cz + 1.55f), V3(0.59f, 0.43f, 0.13f), awning);
    }

    // Shop upgrades add visible golden trim and decorative pennants.
    if (upgradeLevel >= 1) {
        DrawCubeV(V3(cx, 3.49f, cz - 0.18f), V3(5.92f, 0.075f, 3.62f),
                  {220, 177, 91, 255});
        for (int i = 0; i < 5; ++i) {
            const float x = cx - 2.0f + i * 1.0f;
            DrawCylinderEx(V3(x, 3.38f, cz + 1.63f), V3(x, 3.85f, cz + 1.63f),
                           0.025f, 0.025f, 5, {116, 82, 50, 255});
            DrawCubeV(V3(x, 3.78f, cz + 1.63f), V3(0.35f, 0.22f, 0.045f),
                      i % 2 ? Color{247, 224, 164, 255} : Color{185, 75, 62, 255});
        }
    }
    if (upgradeLevel >= 2) {
        for (int side : {-1, 1}) {
            DrawLantern(V3(cx + side * 3.05f, 2.36f, cz + 1.45f),
                        static_cast<unsigned char>(205 + 25 * std::sin(time * 2.0f)));
        }
    }
    if (upgradeLevel >= 3) {
        DrawCubeV(V3(cx, 2.18f, cz - 1.95f), V3(4.0f, 0.08f, 0.08f),
                  {220, 177, 91, 255});
        for (int i = 0; i < 9; ++i) {
            DrawSphere(V3(cx - 1.85f + i * 0.46f, 2.35f, cz - 1.95f), 0.045f,
                       {255, 224, 145, 255});
        }
    }

    // Rounded canopy valance gives the market a more finished silhouette.
    for (int i = 0; i < 10; ++i) {
        const float x = cx - 2.72f + i * 0.605f;
        const Color awning = i % 2 == 0 ? Color{183, 65, 57, 255} : Color{250, 232, 198, 255};
        DrawCylinder(V3(x, 3.05f, cz + 1.55f), 0.16f, 0.16f, 0.32f, 10, awning);
        DrawSphere(V3(x, 2.91f, cz + 1.55f), 0.16f, awning);
    }
    // Warm market bulbs and a hand-made wooden trim.
    DrawCylinderEx(V3(cx - 2.55f, 2.93f, cz + 1.62f),
                   V3(cx + 2.55f, 2.93f, cz + 1.62f), 0.025f, 0.025f, 5,
                   {75, 61, 48, 255});
    for (int i = 0; i < 7; ++i) {
        const float x = cx - 2.1f + i * 0.70f;
        DrawCylinderEx(V3(x, 2.93f, cz + 1.62f), V3(x, 2.72f, cz + 1.62f),
                       0.018f, 0.018f, 5, {89, 68, 47, 255});
        DrawSphere(V3(x, 2.66f, cz + 1.62f), 0.095f, {255, 220, 135, 255});
    }

    // Front counter and countertop.
    DrawCubeV(V3(cx, 0.75f, cz + 1.18f), V3(5.0f, 1.05f, 0.82f), {133, 82, 47, 255});
    DrawCubeV(V3(cx, 1.31f, cz + 1.18f), V3(5.25f, 0.16f, 1.0f), {226, 172, 103, 255});
    DrawCubeV(V3(cx, 1.42f, cz + 1.18f), V3(5.12f, 0.06f, 0.92f), {245, 204, 139, 255});

    // Produce boxes on the counter.
    for (int box = 0; box < 3; ++box) {
        const float x = cx - 1.75f + box * 1.72f;
        DrawCubeV(V3(x, 1.68f, cz + 0.84f), V3(1.35f, 0.48f, 0.68f),
                  {151, 96, 54, 255});
        DrawCubeV(V3(x, 1.94f, cz + 0.84f), V3(1.38f, 0.055f, 0.73f),
                  {186, 128, 76, 255});
        for (int n = 0; n < 5; ++n) {
            const float fx = x - 0.43f + (n % 3) * 0.40f;
            const float fz = cz + 0.72f + (n / 3) * 0.24f;
            const float fy = 2.16f + 0.04f * std::sin(time * 2.0f + n + box);
            if (box == 0) {
                DrawSphere(V3(fx, fy, fz), 0.14f, {236, 124, 42, 255});
                DrawSphere(V3(fx, fy + 0.12f, fz), 0.06f, {66, 147, 69, 255});
            } else if (box == 1) {
                DrawSphere(V3(fx, fy, fz), 0.15f, {205, 57, 52, 255});
                DrawCylinder(V3(fx, fy + 0.14f, fz), 0.025f, 0.025f, 0.10f, 5,
                             {99, 75, 44, 255});
            } else {
                DrawSphere(V3(fx, fy, fz), 0.16f, {236, 145, 43, 255});
                DrawCylinder(V3(fx, fy + 0.15f, fz), 0.025f, 0.04f, 0.11f, 6,
                             {80, 128, 52, 255});
            }
        }
    }

    // Sign above the counter. Text is shown in the HUD for compatibility with Raylib's default font.
    DrawCubeV(V3(cx, 2.58f, cz - 1.91f), V3(3.2f, 0.62f, 0.16f), {107, 69, 43, 255});
    DrawCubeV(V3(cx, 2.58f, cz - 1.80f), V3(3.04f, 0.48f, 0.035f), {243, 214, 157, 255});
    DrawCubeV(V3(cx - 1.43f, 2.58f, cz - 1.76f), V3(0.055f, 0.34f, 0.025f),
              {177, 93, 57, 255});
    DrawCubeV(V3(cx + 1.43f, 2.58f, cz - 1.76f), V3(0.055f, 0.34f, 0.025f),
              {177, 93, 57, 255});
    // Side planters and a small chalkboard menu add shop detail.
    DrawFlowerPot(V3(cx - 2.50f, 0, cz + 1.55f), 0.78f, time);
    DrawFlowerPot(V3(cx + 2.50f, 0, cz + 1.55f), 0.78f, time + 1.2f);
    DrawCubeV(V3(cx + 2.95f, 1.05f, cz + 0.62f), V3(0.60f, 1.55f, 0.12f),
              {94, 64, 46, 255});
    DrawCubeV(V3(cx + 2.95f, 1.08f, cz + 0.69f), V3(0.49f, 1.34f, 0.025f),
              {53, 72, 60, 255});
}

void DrawBarn(Vector3 p) {
    DrawShadow(p, 2.0f, 1.6f, 46);
    DrawCubeV(V3(p.x, 1.2f, p.z), V3(4.0f, 2.4f, 3.4f), {177, 87, 63, 255});
    DrawCubeV(V3(p.x, 1.24f, p.z + 1.73f), V3(3.72f, 2.25f, 0.06f), {205, 105, 75, 255});
    for (int i = 0; i < 7; ++i) {
        DrawCubeV(V3(p.x - 1.55f + i * 0.51f, 1.25f, p.z + 1.78f),
                  V3(0.035f, 2.05f, 0.03f), {147, 70, 55, 255});
    }
    DrawCubeV(V3(p.x, 0.92f, p.z + 1.83f), V3(1.3f, 1.85f, 0.12f), {112, 65, 48, 255});
    DrawCubeV(V3(p.x - 0.31f, 0.95f, p.z + 1.91f), V3(0.06f, 1.75f, 0.05f), {180, 122, 78, 255});
    DrawCubeV(V3(p.x + 0.31f, 0.95f, p.z + 1.91f), V3(0.06f, 1.75f, 0.05f), {180, 122, 78, 255});
    DrawCubeV(V3(p.x, 2.55f, p.z), V3(4.5f, 0.24f, 3.85f), {102, 58, 54, 255});
    DrawCubeV(V3(p.x, 3.0f, p.z), V3(4.15f, 0.16f, 3.55f), {132, 69, 58, 255});
    DrawCubeV(V3(p.x, 3.42f, p.z), V3(3.35f, 0.15f, 2.9f), {150, 78, 61, 255});
    // Roof ridge, end caps and loft vent.
    DrawCylinderEx(V3(p.x - 2.15f, 3.15f, p.z), V3(p.x + 2.15f, 3.15f, p.z),
                   0.11f, 0.11f, 8, {91, 54, 49, 255});
    DrawCubeV(V3(p.x, 2.88f, p.z + 1.91f), V3(1.05f, 0.62f, 0.07f),
              {238, 190, 130, 255});
    DrawCubeV(V3(p.x, 2.88f, p.z + 1.96f), V3(0.12f, 0.48f, 0.035f),
              {137, 77, 57, 255});
    DrawCubeV(V3(p.x, 2.88f, p.z + 1.96f), V3(0.82f, 0.09f, 0.035f),
              {137, 77, 57, 255});
}

void DrawFenceLine(Vector3 a, Vector3 b, float spacing) {
    const float dx = b.x - a.x;
    const float dz = b.z - a.z;
    const float len = std::sqrt(dx * dx + dz * dz);
    const int count = std::max(1, static_cast<int>(len / spacing));
    for (int i = 0; i <= count; ++i) {
        const float t = static_cast<float>(i) / count;
        const float x = a.x + dx * t;
        const float z = a.z + dz * t;
        DrawCubeV(V3(x, 0.60f, z), V3(0.14f, 1.15f, 0.14f), {139, 91, 53, 255});
        DrawCubeV(V3(x, 0.42f, z), V3(0.19f, 0.12f, 0.19f), {178, 127, 79, 255});
    }
    const Vector3 mid = V3((a.x + b.x) * 0.5f, 0, (a.z + b.z) * 0.5f);
    const Vector3 railSize = std::abs(dx) >= std::abs(dz)
        ? V3(len, 0.12f, 0.12f) : V3(0.12f, 0.12f, len);
    for (float y : {0.42f, 0.88f}) {
        DrawCubeV(V3(mid.x, y, mid.z), railSize, {174, 125, 78, 255});
    }
}

void DrawCrate(Vector3 p, Color color) {
    DrawCubeV(V3(p.x, 0.35f, p.z), V3(0.9f, 0.65f, 0.8f), {143, 91, 51, 255});
    for (int i = 0; i < 4; ++i) {
        DrawCubeV(V3(p.x - 0.36f + i * 0.24f, 0.37f, p.z + 0.415f),
                  V3(0.07f, 0.57f, 0.035f), {190, 137, 80, 255});
    }
    DrawCubeV(V3(p.x, 0.68f, p.z), V3(0.94f, 0.07f, 0.84f), color);
}

void DrawTractor(Vector3 p, float time) {
    // A detailed compact farm tractor: rounded hood, open cab, real wheel depth and trim.
    DrawShadow(p, 1.85f, 1.25f, 68);
    const Color tractorGreen = {56, 132, 78, 255};
    const Color tractorHighlight = {89, 169, 95, 255};
    const Color rubber = {42, 48, 45, 255};
    const Color rim = {204, 164, 88, 255};

    DrawCubeV(V3(p.x, 0.78f, p.z - 0.18f), V3(2.2f, 0.48f, 1.05f),
              {58, 74, 58, 255});
    DrawCubeV(V3(p.x, 1.08f, p.z + 0.50f), V3(1.08f, 0.66f, 1.20f), tractorGreen);
    DrawCubeV(V3(p.x, 1.39f, p.z + 0.48f), V3(0.92f, 0.12f, 0.92f), tractorHighlight);
    DrawCubeV(V3(p.x, 0.79f, p.z + 1.08f), V3(1.0f, 0.30f, 0.13f), {65, 72, 62, 255});

    // Rear fenders and four tires with inset hubs.
    for (int side : {-1, 1}) {
        const float x = p.x + side * 0.91f;
        DrawCubeV(V3(x, 1.15f, p.z - 0.43f), V3(0.20f, 0.95f, 1.02f),
                  {62, 137, 78, 255});
        DrawCylinderEx(V3(x - 0.17f, 0.58f, p.z - 0.52f),
                       V3(x + 0.17f, 0.58f, p.z - 0.52f), 0.54f, 0.54f, 20, rubber);
        DrawCylinderEx(V3(x - 0.185f, 0.58f, p.z - 0.52f),
                       V3(x + 0.185f, 0.58f, p.z - 0.52f), 0.29f, 0.29f, 16, rim);
        DrawCylinderEx(V3(x - 0.20f, 0.58f, p.z - 0.52f),
                       V3(x + 0.20f, 0.58f, p.z - 0.52f), 0.11f, 0.11f, 12,
                       {105, 108, 94, 255});

        DrawCylinderEx(V3(x - 0.13f, 0.43f, p.z + 0.77f),
                       V3(x + 0.13f, 0.43f, p.z + 0.77f), 0.34f, 0.34f, 18, rubber);
        DrawCylinderEx(V3(x - 0.145f, 0.43f, p.z + 0.77f),
                       V3(x + 0.145f, 0.43f, p.z + 0.77f), 0.19f, 0.19f, 14, rim);
        DrawCylinderEx(V3(x - 0.15f, 0.43f, p.z + 0.77f),
                       V3(x + 0.15f, 0.43f, p.z + 0.77f), 0.075f, 0.075f, 10,
                       {105, 108, 94, 255});
    }

    // Hood details and grille.
    for (int i = 0; i < 5; ++i) {
        DrawCubeV(V3(p.x - 0.31f + i * 0.155f, 1.12f, p.z + 1.105f),
                  V3(0.045f, 0.34f, 0.025f), {44, 72, 61, 255});
    }
    for (int side : {-1, 1}) {
        DrawSphere(V3(p.x + side * 0.39f, 1.27f, p.z + 1.12f), 0.105f,
                   {255, 227, 145, 255});
        DrawCylinderEx(V3(p.x + side * 0.62f, 0.86f, p.z + 0.60f),
                       V3(p.x + side * 0.82f, 0.74f, p.z + 1.30f),
                       0.07f, 0.055f, 8, {151, 158, 137, 255});
    }

    // Open driver area, seat, steering wheel and roll bar.
    DrawCubeV(V3(p.x, 1.56f, p.z - 0.54f), V3(0.72f, 0.14f, 0.50f),
              {82, 60, 46, 255});
    DrawCubeV(V3(p.x, 1.80f, p.z - 0.77f), V3(0.76f, 0.52f, 0.12f),
              {111, 78, 55, 255});
    DrawCylinderEx(V3(p.x, 1.36f, p.z + 0.08f), V3(p.x, 1.78f, p.z - 0.02f),
                   0.035f, 0.03f, 8, {76, 70, 57, 255});
    DrawCylinder(V3(p.x, 1.80f, p.z - 0.01f), 0.23f, 0.23f, 0.035f, 16,
                 {53, 59, 52, 255});
    DrawCylinderEx(V3(p.x - 0.47f, 1.08f, p.z - 0.74f),
                   V3(p.x - 0.47f, 2.58f, p.z - 0.74f),
                   0.055f, 0.055f, 8, {74, 114, 72, 255});
    DrawCylinderEx(V3(p.x + 0.47f, 1.08f, p.z - 0.74f),
                   V3(p.x + 0.47f, 2.58f, p.z - 0.74f),
                   0.055f, 0.055f, 8, {74, 114, 72, 255});
    DrawCylinderEx(V3(p.x - 0.47f, 2.58f, p.z - 0.74f),
                   V3(p.x + 0.47f, 2.58f, p.z - 0.74f),
                   0.055f, 0.055f, 8, {74, 114, 72, 255});

    // Exhaust pipe and soft animated smoke puffs.
    DrawCylinder(V3(p.x - 0.34f, 1.78f, p.z + 0.38f), 0.055f, 0.075f,
                 0.82f, 9, {72, 76, 64, 255});
    for (int i = 0; i < 3; ++i) {
        const float phase = std::fmod(time * 0.7f + i * 0.34f, 1.0f);
        const float y = 2.26f + phase * 1.12f;
        const float drift = std::sin(time * 1.2f + i) * 0.12f;
        DrawSphere(V3(p.x - 0.34f + drift, y, p.z + 0.38f),
                   0.07f + phase * 0.10f, WithAlpha({221, 225, 214, 255},
                   static_cast<unsigned char>(115 * (1.0f - phase))));
    }
}

void DrawChicken(Vector3 p, float time, float phase) {
    const float bob = std::abs(std::sin(time * 5.0f + phase)) * 0.07f;
    const float step = std::sin(time * 5.0f + phase) * 0.09f;
    DrawShadow(p, 0.30f, 0.24f, 48);
    DrawSphere(V3(p.x, 0.40f + bob, p.z), 0.29f, {245, 238, 218, 255});
    DrawSphere(V3(p.x + 0.18f, 0.57f + bob, p.z + 0.04f), 0.17f,
               {250, 246, 232, 255});
    DrawSphere(V3(p.x + 0.30f, 0.62f + bob, p.z + 0.12f), 0.095f,
               {246, 239, 224, 255});
    DrawSphere(V3(p.x + 0.30f, 0.76f + bob, p.z + 0.08f), 0.07f,
               {196, 57, 49, 255});
    DrawSphere(V3(p.x + 0.34f, 0.62f + bob, p.z + 0.24f), 0.025f,
               {46, 43, 38, 255});
    DrawCylinderEx(V3(p.x + 0.43f, 0.59f + bob, p.z + 0.12f),
                   V3(p.x + 0.56f, 0.56f + bob, p.z + 0.12f),
                   0.055f, 0.008f, 6, {232, 158, 54, 255});
    DrawSphere(V3(p.x - 0.12f, 0.54f + bob, p.z - 0.08f), 0.13f,
               {255, 248, 232, 255});
    for (int leg = 0; leg < 2; ++leg) {
        const float z = p.z + (leg == 0 ? -0.13f : 0.13f);
        DrawCylinderEx(V3(p.x + 0.03f, 0.24f + bob, z),
                       V3(p.x + 0.07f + step, 0.07f, z),
                       0.025f, 0.018f, 5, {227, 145, 51, 255});
        DrawCylinderEx(V3(p.x + 0.07f + step, 0.07f, z),
                       V3(p.x + 0.21f + step, 0.055f, z + 0.015f),
                       0.022f, 0.008f, 5, {227, 145, 51, 255});
    }
}

void SpawnBurst(std::array<Particle, 72>& particles, Vector3 origin,
                Color color, int count, float force) {
    int created = 0;
    for (auto& particle : particles) {
        if (particle.life > 0.0f) continue;
        const float a = Hash01(created * 31 + static_cast<int>(origin.x * 13.0f)) * 6.28318f;
        const float speed = force * (0.45f + Hash01(created * 19 + 4) * 0.85f);
        particle.position = V3(origin.x, origin.y, origin.z);
        particle.velocity = V3(std::cos(a) * speed,
                              1.1f + Hash01(created * 7 + 11) * force,
                              std::sin(a) * speed);
        particle.life = particle.maxLife = 0.65f + Hash01(created * 23 + 8) * 0.65f;
        particle.color = color;
        if (++created >= count) break;
    }
}

void UpdateParticles(std::array<Particle, 72>& particles, float dt) {
    for (auto& particle : particles) {
        if (particle.life <= 0.0f) continue;
        particle.life -= dt;
        particle.position.x += particle.velocity.x * dt;
        particle.position.y += particle.velocity.y * dt;
        particle.position.z += particle.velocity.z * dt;
        particle.velocity.y -= 2.5f * dt;
        particle.velocity.x *= 0.985f;
        particle.velocity.z *= 0.985f;
    }
}

void DrawParticles(const std::array<Particle, 72>& particles) {
    for (const auto& particle : particles) {
        if (particle.life <= 0.0f) continue;
        const float ratio = Clamp(particle.life / particle.maxLife, 0.0f, 1.0f);
        const float radius = 0.035f + (1.0f - ratio) * 0.035f;
        DrawSphere(particle.position, radius,
                   WithAlpha(particle.color, static_cast<unsigned char>(255 * ratio)));
    }
}

void DrawWorld(float time, const std::array<CropField, 3>& fields,
               Vector3 player, float playerYaw, const Customer& customer, float playerPhase,
               const std::array<Particle, 72>& particles, int stallUpgrade) {
    // Soft distant hills add depth beyond the farm fence.
    DrawSphere(V3(-13.8f, -1.6f, -15.3f), 4.8f, {109, 164, 116, 255});
    DrawSphere(V3(-5.3f, -1.9f, -17.1f), 5.4f, {128, 180, 126, 255});
    DrawSphere(V3(4.2f, -2.0f, -17.8f), 5.8f, {111, 164, 116, 255});
    DrawSphere(V3(14.0f, -1.5f, -15.0f), 4.7f, {133, 180, 126, 255});

    // Ground and the warm dirt paths.
    DrawPlane(V3(0, 0, 0), {29.0f, 27.0f}, {112, 171, 91, 255});
    for (int i = 0; i < 24; ++i) {
        const float x = -13.0f + (i * 2.17f) - 1.0f;
        const float z = -10.0f + ((i * 7) % 20);
        DrawCubeV(V3(x, 0.025f, z), V3(0.06f, 0.025f, 0.34f),
                  i % 2 ? Color{137, 190, 103, 255} : Color{91, 155, 80, 255});
    }

    DrawCubeV(V3(-1.8f, 0.035f, 6.45f), V3(18.5f, 0.07f, 2.9f), {193, 151, 98, 255});
    DrawCubeV(V3(-7.0f, 0.04f, 0.6f), V3(2.55f, 0.08f, 11.8f), {193, 151, 98, 255});
    DrawCubeV(V3(2.2f, 0.045f, 2.1f), V3(7.4f, 0.09f, 2.8f), {193, 151, 98, 255});
    DrawCubeV(V3(6.35f, 0.05f, 1.25f), V3(2.8f, 0.10f, 4.4f), {193, 151, 98, 255});

    // A softly curved grass edge and small tufts make the ground feel less empty.
    for (int i = 0; i < 188; ++i) {
        const float x = -12.4f + Hash01(i * 17 + 3) * 24.8f;
        const float z = -11.3f + Hash01(i * 29 + 7) * 22.6f;
        const bool nearField = (x < -4.2f && z > -8.0f && z < 6.7f);
        const bool nearStall = (x > 3.1f && x < 9.8f && z > -4.8f && z < 0.9f);
        const bool nearBarn = (x > 7.1f && z > 4.5f && z < 9.1f);
        const bool onPath = (z > 5.0f && z < 7.9f) ||
                            (x > -8.5f && x < -5.6f && z > -5.5f && z < 7.0f) ||
                            (x > -1.6f && x < 5.8f && z > 0.7f && z < 3.5f);
        if (!nearField && !nearStall && !nearBarn && !onPath) {
            DrawGrassTuft(x, z, 0.70f + Hash01(i * 43) * 0.55f,
                          Hash01(i * 11) * 6.28f, i % 5 == 0);
        }
    }

    // Flower borders around the entrance and the footpath.
    for (int i = 0; i < 21; ++i) {
        const float x = -5.1f + i * 0.56f;
        DrawGrassTuft(x, 8.05f + 0.08f * std::sin(i * 0.8f), 0.92f,
                      i * 0.7f, true);
    }
    for (int i = 0; i < 11; ++i) {
        const float z = -4.1f + i * 0.88f;
        DrawGrassTuft(1.65f + 0.06f * std::sin(i), z, 0.78f,
                      i * 0.9f, i % 2 == 0);
    }

    // Dense, varied flower and grass border along the farm paths.
    for (int i = 0; i < 34; ++i) {
        const float z = -4.8f + i * 0.39f;
        const float x = -5.55f + 0.12f * std::sin(i * 0.62f);
        DrawGrassTuft(x, z, 0.55f + Hash01(i * 71 + 9) * 0.45f,
                      i * 0.37f, i % 4 == 0);
    }

    // Small herb patches beside the barn and the tractor parking area.
    for (int i = 0; i < 18; ++i) {
        const float x = 2.1f + Hash01(i * 53 + 2) * 3.6f;
        const float z = 8.2f + Hash01(i * 37 + 6) * 2.8f;
        DrawGrassTuft(x, z, 0.52f + Hash01(i * 17) * 0.4f,
                      Hash01(i * 9) * 6.28f, i % 3 == 0);
    }

    // Pebbles on the paths.
    for (int i = 0; i < 76; ++i) {
        const float x = -10.5f + (i * 37 % 190) * 0.1f;
        const float z = 5.35f + (i * 13 % 20) * 0.11f;
        DrawSphere(V3(x, 0.10f, z), 0.045f + (i % 3) * 0.012f,
                   {157, 117, 73, 255});
    }

    // Irregular stepping stones make the path feel hand-laid, not like a flat strip.
    for (int i = 0; i < 13; ++i) {
        const float z = 4.45f + i * 0.31f;
        const float x = 2.15f + 0.10f * std::sin(i * 1.7f);
        DrawCubeV(V3(x, 0.105f, z), V3(0.47f, 0.09f, 0.27f),
                  i % 2 ? Color{181, 157, 121, 255} : Color{204, 180, 142, 255});
    }

    // Boundary fence.
    DrawFenceLine(V3(-13.2f, 0, -12.0f), V3(13.2f, 0, -12.0f), 2.0f);
    DrawFenceLine(V3(-13.2f, 0, 12.0f), V3(13.2f, 0, 12.0f), 2.0f);
    DrawFenceLine(V3(-13.2f, 0, -12.0f), V3(-13.2f, 0, 12.0f), 2.0f);
    DrawFenceLine(V3(13.2f, 0, -12.0f), V3(13.2f, 0, 12.0f), 2.0f);

    for (int i = 0; i < static_cast<int>(fields.size()); ++i) DrawField(fields[i], time, i);

    DrawMarketStall(time, stallUpgrade);
    DrawBarn(V3(9.5f, 0, 6.7f));

    DrawTree(V3(-11.0f, 0, -8.7f), 1.0f, time, true);
    DrawTree(V3(-11.4f, 0, 8.5f), 0.86f, time, false);
    DrawTree(V3(11.5f, 0, -8.3f), 0.96f, time, true);
    DrawTree(V3(5.1f, 0, 9.3f), 0.82f, time, false);
    DrawTree(V3(-2.8f, 0, -10.3f), 0.70f, time, true);
    DrawTree(V3(11.5f, 0, 2.4f), 0.67f, time, false);

    // A windmill is the visual landmark behind the orchards.
    DrawWindmill(V3(1.7f, 0, -9.0f), time);
    DrawBench(V3(-3.4f, 0, 9.1f));
    DrawFlowerPot(V3(-4.0f, 0, 8.8f), 0.95f, time);
    DrawFlowerPot(V3(-2.2f, 0, 8.9f), 0.82f, time + 0.8f);
    // A small detailed tractor and wandering hens make the farm feel lived in.
    DrawTractor(V3(1.1f, 0, 8.6f), time);
    DrawChicken(V3(7.1f + std::sin(time * 0.34f) * 0.45f, 0,
                   9.75f + std::cos(time * 0.31f) * 0.34f), time, 0.4f);
    DrawChicken(V3(6.4f + std::sin(time * 0.28f + 1.4f) * 0.55f, 0,
                   10.55f + std::cos(time * 0.30f + 1.4f) * 0.36f), time, 2.0f);
    DrawChicken(V3(8.0f + std::sin(time * 0.25f + 2.3f) * 0.50f, 0,
                   10.85f + std::cos(time * 0.28f + 2.3f) * 0.30f), time, 3.2f);

    DrawCrate(V3(8.7f, 0, 3.75f), {190, 115, 55, 255});
    DrawCrate(V3(7.6f, 0, 4.2f), {202, 158, 76, 255});
    DrawCylinder(V3(8.1f, 0.58f, 5.1f), 0.40f, 0.40f, 1.1f, 12, {126, 85, 57, 255});
    DrawCylinder(V3(8.1f, 1.15f, 5.1f), 0.43f, 0.43f, 0.10f, 12, {174, 129, 82, 255});

    // A shallow water trough gives the farm a little movement and colour.
    DrawCubeV(V3(-10.4f, 0.28f, 0.7f), V3(1.9f, 0.45f, 1.2f), {118, 83, 55, 255});
    DrawCubeV(V3(-10.4f, 0.52f, 0.7f), V3(1.72f, 0.035f, 1.03f), {82, 169, 197, 255});
    for (int i = 0; i < 3; ++i) {
        DrawSphere(V3(-10.9f + i * 0.46f, 0.57f + std::sin(time * 2.2f + i) * 0.018f,
                      0.60f + std::cos(time * 1.8f + i) * 0.12f), 0.035f,
                   {206, 233, 234, 255});
    }
    DrawRock(V3(-11.45f, 0.04f, 1.48f), 0.24f, {126, 133, 115, 255});
    DrawRock(V3(-9.45f, 0.03f, -0.08f), 0.18f, {151, 145, 122, 255});
    DrawGrassTuft(-10.0f, 1.48f, 0.75f, 0.4f, true);
    DrawGrassTuft(-11.0f, -0.12f, 0.68f, 1.7f, false);

    // Little lanterns and flower clusters near the shop entrance.
    DrawLantern(V3(3.55f, 2.48f, -0.78f), 215);
    DrawLantern(V3(9.20f, 2.48f, -0.78f), 215);

    if (customer.active) {
        const Vector3 cp = V3(4.15f, 0, 1.25f);
        const float customerYaw = std::atan2(6.4f - cp.x, -2.4f - cp.z);
        DrawPerson(cp, customerYaw, customer.shirt, customer.pants, false, customer.idleTime);
        DrawSphere(V3(cp.x, 2.44f + std::sin(time * 2.0f) * 0.05f, cp.z), 0.055f,
                   {255, 241, 157, 255});
    }

    DrawPerson(player, playerYaw, {63, 139, 91, 255}, {70, 84, 112, 255}, true, playerPhase);
    DrawParticles(particles);

    // Low-poly butterflies near the flower beds.
    for (int i = 0; i < 5; ++i) {
        const float x = -10.0f + i * 1.1f + std::sin(time * 1.2f + i) * 0.38f;
        const float z = -3.2f + std::cos(time * 1.1f + i * 0.8f) * 0.65f;
        const float y = 1.0f + std::sin(time * 2.3f + i) * 0.25f;
        const Color wing = i % 2 ? Color{255, 220, 126, 255} : Color{244, 178, 199, 255};
        DrawSphere(V3(x - 0.09f, y, z), 0.075f, wing);
        DrawSphere(V3(x + 0.09f, y, z), 0.075f, wing);
        DrawSphere(V3(x, y, z), 0.035f, {63, 56, 50, 255});
    }

    // Clouds and sun are simple 3D objects, so the whole scene is self-contained.
    DrawSphere(V3(-7.0f + std::sin(time * 0.07f) * 1.5f, 10.0f, -9.0f), 1.15f,
               WithAlpha(WHITE, 235));
    DrawSphere(V3(2.0f + std::sin(time * 0.05f + 2.0f), 11.0f, -10.5f), 1.4f,
               WithAlpha(WHITE, 225));
    DrawSphere(V3(9.2f, 12.0f, -10.0f), 1.1f, {255, 232, 157, 255});
}

void DrawCropIcon2D(int x, int y, int type) {
    if (type == 0) {
        DrawTriangle({static_cast<float>(x - 8), static_cast<float>(y - 1)},
                     {static_cast<float>(x + 8), static_cast<float>(y - 1)},
                     {static_cast<float>(x), static_cast<float>(y + 17)}, {238, 125, 43, 255});
        DrawLineEx({static_cast<float>(x), static_cast<float>(y - 2)},
                   {static_cast<float>(x - 7), static_cast<float>(y - 13)}, 3, CROPS[0].leaf);
        DrawLineEx({static_cast<float>(x), static_cast<float>(y - 2)},
                   {static_cast<float>(x + 7), static_cast<float>(y - 13)}, 3, CROPS[0].leaf);
    } else if (type == 1) {
        DrawCircle(x, y + 4, 10, CROPS[1].main);
        DrawLineEx({static_cast<float>(x), static_cast<float>(y - 5)},
                   {static_cast<float>(x + 2), static_cast<float>(y - 12)}, 3.0f,
                   {107, 76, 45, 255});
        DrawEllipse(x + 7, y - 9, 6, 3, CROPS[1].leaf);
    } else {
        DrawCircle(x, y + 4, 11, CROPS[2].main);
        DrawEllipse(x - 5, y + 4, 4, 9, {251, 172, 66, 255});
        DrawEllipse(x + 5, y + 4, 4, 9, {210, 115, 38, 255});
    }
}

void DrawHud(int coins, const std::array<int, 3>& inventory,
             const std::array<int, 3>& seeds, const Customer& customer, int served,
             int stallUpgrade, bool nearField, bool nearMarket,
             bool helpVisible, bool paused, const Message& message) {
    DrawRectangleRounded({18, 18, 350, 194}, 0.12f, 12, Fade({28, 42, 48, 255}, 0.91f));
    DrawRectangleRounded({28, 28, 330, 42}, 0.14f, 8, {55, 105, 73, 255});
    DrawCircle(43, 49, 7, {255, 218, 123, 255});
    DrawText("LITTLE FARM MARKET 3D", 58, 39, 21, RAYWHITE);
    DrawText(TextFormat("COINS  %i", coins), 36, 88, 25, {255, 222, 122, 255});
    DrawText(TextFormat("CUSTOMERS SERVED  %i", served), 38, 126, 17, {219, 231, 220, 255});
    DrawText(TextFormat("MARKET LEVEL  %i / 3", stallUpgrade), 38, 151, 14,
             {185, 221, 174, 255});
    const int nextUpgradeCost = stallUpgrade == 0 ? 60 : (stallUpgrade == 1 ? 110 : (stallUpgrade == 2 ? 180 : 0));
    DrawText(nextUpgradeCost > 0 ? TextFormat("NEXT UPGRADE  %i COINS", nextUpgradeCost)
                                 : "MARKET FULLY UPGRADED",
             38, 171, 13, {255, 216, 147, 255});

    DrawRectangleRounded({SCREEN_W - 330, 18, 312, 184}, 0.12f, 12, Fade({28, 42, 48, 255}, 0.91f));
    DrawText("YOUR BASKET", SCREEN_W - 303, 35, 19, {255, 229, 168, 255});
    for (int i = 0; i < 3; ++i) {
        const int x = SCREEN_W - 286 + i * 96;
        DrawCropIcon2D(x, 82, i);
        DrawText(TextFormat("%i", inventory[i]), x - 8, 111, 21, RAYWHITE);
        DrawText(TextFormat("KEY %i", i + 1), x - 18, 140, 13, {189, 206, 195, 255});
        DrawText(TextFormat("SEEDS %i", seeds[i]), x - 27, 160, 12, {178, 220, 160, 255});
    }

    DrawRectangleRounded({SCREEN_W / 2 - 188, 18, 376, 82}, 0.12f, 12, Fade({28, 42, 48, 255}, 0.89f));
    if (customer.active) {
        DrawText(TextFormat("CUSTOMER WANTS: %s", CROPS[customer.order].name),
                 SCREEN_W / 2 - 166, 31, 18, {255, 232, 176, 255});
        const float ratio = Clamp(customer.patience / customer.maxPatience, 0.0f, 1.0f);
        DrawRectangleRounded({SCREEN_W / 2 - 164, 64, 326, 15}, 0.3f, 8, {72, 78, 74, 255});
        DrawRectangleRounded({SCREEN_W / 2 - 164, 64, 326 * ratio, 15}, 0.3f, 8,
                             ratio > 0.35f ? Color{100, 190, 111, 255} : Color{222, 94, 70, 255});
        DrawText("PATIENCE", SCREEN_W / 2 - 163, 81, 10, {220, 227, 218, 255});
    } else {
        DrawText("NEXT CUSTOMER IS COMING...", SCREEN_W / 2 - 153, 46, 18, RAYWHITE);
    }

    const int bottomY = SCREEN_H - 72;
    DrawRectangleRounded({18, bottomY, SCREEN_W - 36, 52}, 0.14f, 10, Fade({28, 42, 48, 255}, 0.88f));
#if defined(__ANDROID__)
    if (nearField) {
        DrawText("LEFT STICK: MOVE     PICK / PLANT     WATER",
                 38, bottomY + 16, 18, {255, 226, 148, 255});
    } else if (nearMarket) {
        DrawText("LEFT STICK: MOVE     SELL ORDER     BUY SEEDS     UPGRADE",
                 38, bottomY + 16, 18, {255, 226, 148, 255});
    } else {
        DrawText("LEFT STICK TO MOVE     RIGHT SIDE BUTTONS FOR ACTIONS",
                 38, bottomY + 16, 18, {224, 233, 225, 255});
    }
#else
    if (nearField) {
        DrawText("E  HARVEST RIPE / PLANT SEED     F  WATER GROWING CROPS",
                 38, bottomY + 16, 18, {255, 226, 148, 255});
    } else if (nearMarket) {
        DrawText("1/2/3 SELL     B BUY 5 SEEDS (24 COINS)     U UPGRADE STALL",
                 38, bottomY + 16, 18, {255, 226, 148, 255});
    } else {
        DrawText("WASD MOVE   Q/R CAMERA   WHEEL ZOOM   E HARVEST/PLANT   F WATER",
                 38, bottomY + 16, 17, {224, 233, 225, 255});
    }
#endif
    DrawText(TextFormat("STALL LVL %i", stallUpgrade), SCREEN_W - 490, bottomY + 17,
             15, {255, 218, 139, 255});
    DrawText("F5 SAVE  F9 LOAD  H HELP  P PAUSE", SCREEN_W - 310, bottomY + 17,
             14, {190, 210, 194, 255});

    if (message.timer > 0.0f && !message.text.empty()) {
        const int width = std::min(620, MeasureText(message.text.c_str(), 22) + 54);
        DrawRectangleRounded({SCREEN_W / 2.0f - width / 2.0f, SCREEN_H - 150.0f,
                              static_cast<float>(width), 48}, 0.18f, 10,
                             Fade({30, 42, 45, 255}, 0.91f));
        DrawText(message.text.c_str(), SCREEN_W / 2 - MeasureText(message.text.c_str(), 22) / 2,
                 SCREEN_H - 136, 22, message.color);
    }

    if (helpVisible) {
        DrawRectangleRounded({SCREEN_W / 2.0f - 275, SCREEN_H / 2.0f - 178, 550, 356},
                             0.08f, 14, Fade({25, 38, 43, 255}, 0.97f));
        DrawText("HOW TO PLAY", SCREEN_W / 2 - 102, SCREEN_H / 2 - 150, 28,
                 {255, 225, 156, 255});
#if defined(__ANDROID__)
        DrawText("LEFT STICK      -  Move around the farm", SCREEN_W / 2 - 230,
                 SCREEN_H / 2 - 92, 19, RAYWHITE);
        DrawText("CAM - / CAM +   -  Rotate the camera", SCREEN_W / 2 - 230,
                 SCREEN_H / 2 - 53, 19, RAYWHITE);
        DrawText("RIGHT BUTTONS   -  Harvest, water and sell", SCREEN_W / 2 - 230,
                 SCREEN_H / 2 - 14, 19, RAYWHITE);
#else
        DrawText("WASD / ARROWS  -  Move around the farm", SCREEN_W / 2 - 230,
                 SCREEN_H / 2 - 92, 19, RAYWHITE);
        DrawText("Q / R          -  Rotate the camera", SCREEN_W / 2 - 230,
                 SCREEN_H / 2 - 53, 19, RAYWHITE);
        DrawText("MOUSE WHEEL    -  Zoom in or out", SCREEN_W / 2 - 230,
                 SCREEN_H / 2 - 14, 19, RAYWHITE);
#endif
        DrawText("E near field - Harvest ripe crop or plant a seed", SCREEN_W / 2 - 230,
                 SCREEN_H / 2 + 17, 18, RAYWHITE);
        DrawText("F near field - Water growing crops", SCREEN_W / 2 - 230,
                 SCREEN_H / 2 + 50, 18, RAYWHITE);
        DrawText("1/2/3 sell   B buy seeds   U upgrade stall near shop", SCREEN_W / 2 - 230,
                 SCREEN_H / 2 + 83, 17, RAYWHITE);
        DrawText("F5 - Save game     F9 - Load game", SCREEN_W / 2 - 230,
                 SCREEN_H / 2 + 120, 17, {190, 225, 183, 255});
        DrawText("H - Close help     P / ESC - Pause", SCREEN_W / 2 - 230,
                 SCREEN_H / 2 + 148, 17, {255, 222, 144, 255});
    }

    if (paused) {
        DrawRectangle(0, 0, SCREEN_W, SCREEN_H, Fade(BLACK, 0.48f));
        DrawRectangleRounded({SCREEN_W / 2.0f - 170, SCREEN_H / 2.0f - 74, 340, 148},
                             0.12f, 12, Fade({30, 45, 48, 255}, 0.96f));
        DrawText("PAUSED", SCREEN_W / 2 - 72, SCREEN_H / 2 - 35, 36, RAYWHITE);
        DrawText("Press P or ESC to continue", SCREEN_W / 2 - 137,
                 SCREEN_H / 2 + 18, 18, {255, 223, 154, 255});
    }
}


struct TouchControls {
    float forward = 0.0f;
    float strafe = 0.0f;
    bool action = false;
    bool water = false;
    bool buy = false;
    bool upgrade = false;
    bool save = false;
    bool load = false;
    bool help = false;
    bool pause = false;
    bool rotateLeftDown = false;
    bool rotateRightDown = false;
};

float GetUiScale() {
    const float sx = static_cast<float>(GetScreenWidth()) / SCREEN_W;
    const float sy = static_cast<float>(GetScreenHeight()) / SCREEN_H;
    return std::max(0.01f, std::min(sx, sy));
}

Vector2 GetUiOffset(float scale) {
    return {(GetScreenWidth() - SCREEN_W * scale) * 0.5f,
            (GetScreenHeight() - SCREEN_H * scale) * 0.5f};
}

#if defined(__ANDROID__)
Vector2 ScreenToUi(Vector2 point) {
    const float scale = GetUiScale();
    const Vector2 offset = GetUiOffset(scale);
    return {(point.x - offset.x) / scale, (point.y - offset.y) / scale};
}

bool AnyTouchIn(Rectangle rect) {
    const int count = std::min(GetTouchPointCount(), 8);
    for (int i = 0; i < count; ++i) {
        const Vector2 p = ScreenToUi(GetTouchPosition(i));
        if (CheckCollisionPointRec(p, rect)) return true;
    }
    return false;
}

bool TouchPressed(Rectangle rect, bool& wasDown) {
    const bool down = AnyTouchIn(rect);
    const bool pressed = down && !wasDown;
    wasDown = down;
    return pressed;
}

TouchControls ReadTouchControls() {
    static bool actionWasDown = false;
    static bool waterWasDown = false;
    static bool buyWasDown = false;
    static bool upgradeWasDown = false;
    static bool saveWasDown = false;
    static bool loadWasDown = false;
    static bool helpWasDown = false;
    static bool pauseWasDown = false;

    TouchControls result{};
    const int count = std::min(GetTouchPointCount(), 8);
    for (int i = 0; i < count; ++i) {
        const Vector2 p = ScreenToUi(GetTouchPosition(i));
        // Virtual joystick: a finger may be placed anywhere in the lower-left pad.
        if (p.x >= 35.0f && p.x <= 275.0f && p.y >= 600.0f && p.y <= 890.0f) {
            float dx = (p.x - 165.0f) / 92.0f;
            float dy = (p.y - 750.0f) / 92.0f;
            const float length = std::sqrt(dx*dx + dy*dy);
            if (length > 1.0f) { dx /= length; dy /= length; }
            result.strafe = dx;
            result.forward = -dy;
        }
    }
    // Button rectangles are kept in the same virtual 1440x900 space as the HUD.
    result.action = TouchPressed({1240, 670, 170, 170}, actionWasDown);
    result.water = TouchPressed({1085, 770, 130, 110}, waterWasDown);
    result.buy = TouchPressed({1040, 555, 150, 82}, buyWasDown);
    result.upgrade = TouchPressed({1205, 555, 190, 82}, upgradeWasDown);
    result.save = TouchPressed({300, 780, 88, 76}, saveWasDown);
    result.load = TouchPressed({395, 780, 88, 76}, loadWasDown);
    result.help = TouchPressed({1320, 210, 82, 58}, helpWasDown);
    result.pause = TouchPressed({1230, 210, 82, 58}, pauseWasDown);
    result.rotateLeftDown = AnyTouchIn({890, 770, 86, 86});
    result.rotateRightDown = AnyTouchIn({980, 770, 86, 86});
    return result;
}

void DrawTouchButton(Rectangle rect, const char* label, Color tint = {255, 255, 255, 230}) {
    DrawRectangleRounded(rect, 0.28f, 12, Fade({24, 37, 41, 255}, 0.78f));
    DrawRectangleRoundedLines(rect, 0.28f, 12, 2.0f, Fade(tint, 0.78f));
    const int fontSize = 17;
    const int tw = MeasureText(label, fontSize);
    DrawText(label, static_cast<int>(rect.x + (rect.width - tw) * 0.5f),
             static_cast<int>(rect.y + (rect.height - fontSize) * 0.5f), fontSize, tint);
}

void DrawTouchControls(bool nearField, bool nearMarket) {
    // Left thumb movement pad.
    DrawCircle(165, 750, 105, Fade({27, 42, 45, 255}, 0.34f));
    DrawCircleLines(165, 750, 105, Fade({245, 244, 217, 255}, 0.50f));
    DrawCircle(165, 750, 37, Fade({228, 235, 218, 255}, 0.38f));
    DrawText("MOVE", 132, 744, 15, Fade(WHITE, 0.88f));

    DrawTouchButton({1240, 670, 170, 170}, nearMarket ? "SELL ORDER" : "PICK / PLANT",
                    {255, 224, 153, 255});
    if (nearField) DrawTouchButton({1085, 770, 130, 110}, "WATER", {170, 223, 244, 255});
    if (nearMarket) {
        DrawTouchButton({1040, 555, 150, 82}, "BUY SEEDS", {183, 235, 164, 255});
        DrawTouchButton({1205, 555, 190, 82}, "UPGRADE", {255, 221, 137, 255});
    }
    DrawTouchButton({890, 770, 86, 86}, "TURN L", {218, 232, 228, 255});
    DrawTouchButton({980, 770, 86, 86}, "TURN R", {218, 232, 228, 255});
    DrawTouchButton({300, 780, 88, 76}, "SAVE", {177, 224, 173, 255});
    DrawTouchButton({395, 780, 88, 76}, "LOAD", {174, 207, 237, 255});
    DrawTouchButton({1230, 210, 82, 58}, "PAUSE", {255, 218, 145, 255});
    DrawTouchButton({1320, 210, 82, 58}, "HELP", {224, 233, 222, 255});
}
#else
TouchControls ReadTouchControls() { return {}; }
void DrawTouchControls(bool, bool) {}
#endif

} // namespace

int main() {
    SetConfigFlags(FLAG_MSAA_4X_HINT | FLAG_VSYNC_HINT);
    InitWindow(SCREEN_W, SCREEN_H, "Little Farm Market 3D - C++");
    SetTargetFPS(60);

    // Enable a soft warm key light, cool ambient fill, subtle highlights and distance haze.
    Shader farmLighting = LoadShaderFromMemory(FARM_VERTEX_SHADER, FARM_FRAGMENT_SHADER);
    const bool lightingReady = farmLighting.id != 0;
    const int lightDirectionLoc = lightingReady ? GetShaderLocation(farmLighting, "lightDirection") : -1;
    const int viewDirectionLoc = lightingReady ? GetShaderLocation(farmLighting, "viewDirection") : -1;
    Vector3 lightDirection = {-0.48f, -1.0f, -0.38f};

    std::array<CropField, 3> fields{{
        MakeField(V3(-7.0f, 0, -6.0f), 0),
        MakeField(V3(-7.0f, 0, -0.7f), 1),
        MakeField(V3(-7.0f, 0, 4.6f), 2)
    }};

    Vector3 player = V3(0.0f, 0.0f, 4.0f);
    float playerYaw = 0.0f;
    float playerPhase = 0.0f;
    std::array<Particle, 72> particles{};
    float cameraYaw = 0.62f;
    float cameraDistance = 17.0f;
    bool helpVisible = false;
    bool paused = false;
    int coins = 0;
    int customersServed = 0;
    std::array<int, 3> inventory{{0, 0, 0}};
    std::array<int, 3> seeds{{6, 6, 6}};
    int stallUpgrade = 0;
    Customer customer;
    customer.order = std::rand() % 3;
    Message message;
    float worldTime = 0.0f;
#if defined(__ANDROID__)
    const std::string savePath = g_androidSavePath;
#else
    const std::string savePath = "farm_market_save.dat";
#endif

    Camera3D camera{};
    camera.position = V3(12, 16, 15);
    camera.target = V3(0, 1, 0);
    camera.up = V3(0, 1, 0);
    camera.fovy = 48.0f;
    camera.projection = CAMERA_PERSPECTIVE;

    while (!WindowShouldClose()) {
        const float dt = std::min(GetFrameTime(), 0.04f);
        worldTime += dt;
        const TouchControls touch = ReadTouchControls();

        if (IsKeyPressed(KEY_H) || touch.help) helpVisible = !helpVisible;
        if (IsKeyPressed(KEY_P) || IsKeyPressed(KEY_ESCAPE) || touch.pause) paused = !paused;
        if (IsKeyPressed(KEY_F5) || touch.save) {
            const bool saved = SaveGame(savePath, coins, customersServed, stallUpgrade,
                                        inventory, seeds, fields);
            Say(message, saved ? "Game saved successfully." : "Could not write the save file.",
                saved ? Color{169, 236, 168, 255} : Color{255, 177, 145, 255});
        }
        if (IsKeyPressed(KEY_F9) || touch.load) {
            const bool loaded = LoadGame(savePath, coins, customersServed, stallUpgrade,
                                         inventory, seeds, fields);
            Say(message, loaded ? "Saved game loaded." : "No valid save file was found.",
                loaded ? Color{169, 236, 168, 255} : Color{255, 177, 145, 255});
            if (loaded) {
                customer.active = true;
                customer.patience = customer.maxPatience + stallUpgrade * 5.0f;
                customer.maxPatience = customer.patience;
                customer.order = std::rand() % 3;
            }
        }

        if (!paused && !helpVisible) {
            // Camera rotation and zoom.
            if (IsKeyDown(KEY_Q) || touch.rotateLeftDown) cameraYaw -= 1.25f * dt;
            if (IsKeyDown(KEY_R) || touch.rotateRightDown) cameraYaw += 1.25f * dt;
            cameraDistance = Clamp(cameraDistance - GetMouseWheelMove() * 1.2f, 10.5f, 25.0f);

            // Move relative to the camera heading.
            float forward = touch.forward;
            float strafe = touch.strafe;
            if (IsKeyDown(KEY_W) || IsKeyDown(KEY_UP)) forward += 1.0f;
            if (IsKeyDown(KEY_S) || IsKeyDown(KEY_DOWN)) forward -= 1.0f;
            if (IsKeyDown(KEY_D) || IsKeyDown(KEY_RIGHT)) strafe += 1.0f;
            if (IsKeyDown(KEY_A) || IsKeyDown(KEY_LEFT)) strafe -= 1.0f;
            Vector3 move = V3(-std::sin(cameraYaw) * forward + std::cos(cameraYaw) * strafe,
                              0.0f,
                              -std::cos(cameraYaw) * forward - std::sin(cameraYaw) * strafe);
            const float moveLen = std::sqrt(move.x * move.x + move.z * move.z);
            if (moveLen > 0.001f) {
                move.x /= moveLen;
                move.z /= moveLen;
                player.x += move.x * PLAYER_SPEED * dt;
                player.z += move.z * PLAYER_SPEED * dt;
                playerYaw = std::atan2(move.x, move.z);
                playerPhase += dt * 7.0f;
            }
            player.x = Clamp(player.x, -11.6f, 11.6f);
            player.z = Clamp(player.z, -10.5f, 10.5f);

            // Planted crops pass through seedling, growing and ripe stages.
            // Watering accelerates growth for a short period.
            for (auto& field : fields) {
                for (int plot = 0; plot < MAX_FIELD_CROPS; ++plot) {
                    if (field.wetTimer[plot] > 0.0f) field.wetTimer[plot] = std::max(0.0f, field.wetTimer[plot] - dt);
                    if (field.stage[plot] > 0 && field.stage[plot] < 3) {
                        const float growthRate = field.wetTimer[plot] > 0.0f ? 1.85f : 1.0f;
                        field.growth[plot] += dt * growthRate;
                        if (field.growth[plot] >= CROP_STAGE_SECONDS) {
                            field.growth[plot] -= CROP_STAGE_SECONDS;
                            field.stage[plot]++;
                            if (field.stage[plot] >= 3) {
                                field.stage[plot] = 3;
                                field.growth[plot] = 0.0f;
                                SpawnBurst(particles, V3(field.center.x, 0.95f, field.center.z),
                                           {188, 220, 115, 255}, 5, 0.65f);
                            }
                        }
                    }
                }
            }

            customer.idleTime += dt;
            if (customer.active) {
                customer.patience -= dt;
                if (customer.patience <= 0.0f) {
                    customer.active = false;
                    customer.spawnTimer = 2.2f;
                    Say(message, "The customer left. A new one is on the way.", {247, 177, 132, 255});
                }
            } else {
                customer.spawnTimer -= dt;
                if (customer.spawnTimer <= 0.0f) {
                    customer.active = true;
                    customer.order = std::rand() % 3;
                    customer.patience = customer.maxPatience;
                    customer.shirt = std::array<Color, 4>{{
                        Color{76, 136, 190, 255}, Color{181, 107, 105, 255},
                        Color{198, 151, 78, 255}, Color{115, 124, 177, 255}
                    }}[std::rand() % 4];
                    Say(message, "A new customer has arrived!", {175, 235, 174, 255});
                }
            }

            // Find the closest crop field.
            int nearestField = -1;
            float nearestFieldDistance = 999.0f;
            for (int i = 0; i < static_cast<int>(fields.size()); ++i) {
                const float d = DistanceXZ(player, fields[i].center);
                if (d < nearestFieldDistance) {
                    nearestFieldDistance = d;
                    nearestField = i;
                }
            }
            const bool nearField = nearestField >= 0 && nearestFieldDistance < FIELD_RADIUS;
            const bool nearMarket = DistanceXZ(player, V3(6.3f, 0, 2.0f)) < MARKET_RADIUS;

            if ((IsKeyPressed(KEY_E) || touch.action) && nearField) {
                CropField& field = fields[nearestField];
                int ripePlot = -1;
                int emptyPlot = -1;
                for (int plot = 0; plot < MAX_FIELD_CROPS; ++plot) {
                    if (field.stage[plot] == 3 && ripePlot < 0) ripePlot = plot;
                    if (field.stage[plot] == 0 && emptyPlot < 0) emptyPlot = plot;
                }
                if (ripePlot >= 0) {
                    field.stage[ripePlot] = 0;
                    field.growth[ripePlot] = 0.0f;
                    field.wetTimer[ripePlot] = 0.0f;
                    inventory[field.cropType]++;
                    const Color harvestTint = field.cropType == 0 ? Color{255, 175, 77, 255} :
                                              (field.cropType == 1 ? Color{237, 93, 78, 255} : Color{255, 190, 86, 255});
                    const float x = field.center.x - 1.68f + (ripePlot % 5) * 0.83f;
                    const float z = field.center.z - 1.03f + (ripePlot / 5) * 1.03f;
                    SpawnBurst(particles, V3(x, 0.95f, z), harvestTint, 16, 1.45f);
                    Say(message, std::string("Harvested 1 ") + CROPS[field.cropType].name + "!",
                        {169, 236, 168, 255});
                } else if (emptyPlot >= 0 && seeds[field.cropType] > 0) {
                    seeds[field.cropType]--;
                    field.stage[emptyPlot] = 1;
                    field.growth[emptyPlot] = 0.0f;
                    const float x = field.center.x - 1.68f + (emptyPlot % 5) * 0.83f;
                    const float z = field.center.z - 1.03f + (emptyPlot / 5) * 1.03f;
                    SpawnBurst(particles, V3(x, 0.55f, z), {151, 196, 112, 255}, 8, 0.75f);
                    Say(message, std::string("Planted a ") + CROPS[field.cropType].name + " seed.",
                        {169, 236, 168, 255});
                } else if (emptyPlot >= 0) {
                    Say(message, "No seeds left. Buy a seed pack at the market (B).",
                        {255, 205, 139, 255});
                } else {
                    Say(message, "Your crops are still growing. Come back soon!",
                        {255, 215, 145, 255});
                }
            }

            if ((IsKeyPressed(KEY_F) || touch.water) && nearField) {
                CropField& field = fields[nearestField];
                int watered = 0;
                for (int plot = 0; plot < MAX_FIELD_CROPS; ++plot) {
                    if (field.stage[plot] > 0 && field.stage[plot] < 3) {
                        field.wetTimer[plot] = 9.0f;
                        watered++;
                    }
                }
                if (watered > 0) {
                    SpawnBurst(particles, V3(field.center.x, 0.65f, field.center.z),
                               {115, 197, 223, 255}, 14, 1.0f);
                    Say(message, "Watered the growing crops. They will grow faster!",
                        {156, 218, 238, 255});
                } else {
                    Say(message, "Nothing needs watering in this field yet.",
                        {255, 215, 145, 255});
                }
            }

            if (nearMarket && (IsKeyPressed(KEY_B) || touch.buy)) {
                if (coins >= SEED_PACK_PRICE) {
                    coins -= SEED_PACK_PRICE;
                    for (int type = 0; type < 3; ++type) seeds[type] += SEED_PACK_SIZE;
                    SpawnBurst(particles, V3(6.3f, 2.05f, 0.0f), {165, 209, 132, 255}, 16, 1.2f);
                    Say(message, "+5 seeds of each crop added to your bag.", {177, 238, 163, 255});
                } else {
                    Say(message, "You need 24 coins for a mixed seed pack.", {255, 190, 145, 255});
                }
            }

            if (nearMarket && (IsKeyPressed(KEY_U) || touch.upgrade)) {
                const int upgradeCost = stallUpgrade == 0 ? 60 : (stallUpgrade == 1 ? 110 : 180);
                if (stallUpgrade >= MAX_STALL_UPGRADE) {
                    Say(message, "Your market is fully upgraded!", {255, 226, 133, 255});
                } else if (coins >= upgradeCost) {
                    coins -= upgradeCost;
                    stallUpgrade++;
                    customer.maxPatience += 5.0f;
                    customer.patience = std::min(customer.maxPatience, customer.patience + 12.0f);
                    SpawnBurst(particles, V3(6.3f, 3.2f, -0.2f), {255, 222, 126, 255}, 30, 2.1f);
                    Say(message, "Market upgraded! Better look and +10% sale value.",
                        {255, 226, 133, 255});
                } else {
                    Say(message, std::string("Next market upgrade costs ") + std::to_string(upgradeCost) + " coins.",
                        {255, 190, 145, 255});
                }
            }

            if (nearMarket && customer.active) {
                for (int type = 0; type < 3; ++type) {
                    const int key = type == 0 ? KEY_ONE : (type == 1 ? KEY_TWO : KEY_THREE);
                    if (IsKeyPressed(key) || (touch.action && type == customer.order)) {
                        if (inventory[type] <= 0) {
                            Say(message, std::string("You have no ") + CROPS[type].name + "s in your basket.",
                                {255, 190, 145, 255});
                        } else if (type != customer.order) {
                            Say(message, std::string("The customer asked for ") + CROPS[customer.order].name + ".",
                                {255, 205, 139, 255});
                        } else {
                            inventory[type]--;
                            const int saleValue = CROPS[type].price * (100 + stallUpgrade * 10) / 100;
                            coins += saleValue;
                            customersServed++;
                            const Color saleTint = type == 0 ? Color{255, 174, 70, 255} :
                                                   (type == 1 ? Color{238, 88, 78, 255} : Color{255, 207, 93, 255});
                            SpawnBurst(particles, V3(6.3f, 2.05f, 0.0f), saleTint, 22, 2.2f);
                            customer.active = false;
                            customer.spawnTimer = 1.4f;
                            Say(message, std::string("Sold ") + CROPS[type].name + "!  +" +
                                std::to_string(saleValue) + " coins",
                                {255, 226, 133, 255});
                        }
                    }
                }
            }

            if (message.timer > 0.0f) message.timer -= dt;
            UpdateParticles(particles, dt);
        } else {
            // Keep the scene animation alive while help is open, but stop game timers when paused.
            if (!paused) worldTime += dt * 0.25f;
        }

        const Vector3 target = V3(player.x, 0.9f, player.z);
        camera.target = target;
        camera.position = V3(player.x + std::sin(cameraYaw) * cameraDistance,
                             player.y + cameraDistance * 0.68f,
                             player.z + std::cos(cameraYaw) * cameraDistance);

        const int currentWidth = GetScreenWidth();
        const int currentHeight = GetScreenHeight();
        (void)currentWidth;
        (void)currentHeight;

        int nearestField = -1;
        float nearestFieldDistance = 999.0f;
        for (int i = 0; i < static_cast<int>(fields.size()); ++i) {
            const float d = DistanceXZ(player, fields[i].center);
            if (d < nearestFieldDistance) {
                nearestFieldDistance = d;
                nearestField = i;
            }
        }
        const bool nearField = nearestField >= 0 && nearestFieldDistance < FIELD_RADIUS;
        const bool nearMarket = DistanceXZ(player, V3(6.3f, 0, 2.0f)) < MARKET_RADIUS;

        BeginDrawing();
        ClearBackground({149, 204, 229, 255});
        // Soft warm sky gradient gives the low-poly world a brighter, illustrated look.
        DrawRectangleGradientV(0, 0, GetScreenWidth(), GetScreenHeight(),
                               {116, 181, 218, 255}, {232, 220, 178, 255});
        DrawCircleGradient(GetScreenWidth() - 150, 130, 92,
                           Fade({255, 237, 176, 255}, 0.30f), Fade({255, 237, 176, 255}, 0.0f));
        BeginMode3D(camera);
        if (lightingReady) {
            // Very slow sun movement creates a gentle time-of-day shift across the scene.
            lightDirection = V3(-0.48f + std::sin(worldTime * 0.045f) * 0.16f,
                                -1.0f,
                                -0.38f + std::cos(worldTime * 0.045f) * 0.10f);
            const Vector3 viewDirection = {
                camera.position.x - camera.target.x,
                camera.position.y - camera.target.y,
                camera.position.z - camera.target.z
            };
            if (lightDirectionLoc >= 0) {
                SetShaderValue(farmLighting, lightDirectionLoc, &lightDirection, SHADER_UNIFORM_VEC3);
            }
            if (viewDirectionLoc >= 0) {
                SetShaderValue(farmLighting, viewDirectionLoc, &viewDirection, SHADER_UNIFORM_VEC3);
            }
            BeginShaderMode(farmLighting);
        }
        DrawWorld(worldTime, fields, player, playerYaw, customer, playerPhase, particles, stallUpgrade);
        if (lightingReady) EndShaderMode();
        EndMode3D();

        // Keep the HUD and touch controls proportional on tall/high-DPI Android displays.
        const float uiScale = GetUiScale();
        const Vector2 uiOffset = GetUiOffset(uiScale);
        Camera2D uiCamera{};
        uiCamera.offset = uiOffset;
        uiCamera.target = {0.0f, 0.0f};
        uiCamera.rotation = 0.0f;
        uiCamera.zoom = uiScale;
        BeginMode2D(uiCamera);
        DrawHud(coins, inventory, seeds, customer, customersServed, stallUpgrade,
                nearField, nearMarket, helpVisible, paused, message);
#if defined(__ANDROID__)
        DrawTouchControls(nearField, nearMarket);
#endif
        EndMode2D();
        EndDrawing();
    }

    if (lightingReady) UnloadShader(farmLighting);
    CloseWindow();
    return 0;
}

#if defined(__ANDROID__)
extern "C" JNIEXPORT void JNICALL
Java_com_openai_farmmarket_FarmMarketActivity_nativeSetSavePath(JNIEnv* env, jclass, jstring path) {
    if (path == nullptr) return;
    const char* utf = env->GetStringUTFChars(path, nullptr);
    if (utf != nullptr) {
        g_androidSavePath.assign(utf);
        env->ReleaseStringUTFChars(path, utf);
    }
}
#endif
