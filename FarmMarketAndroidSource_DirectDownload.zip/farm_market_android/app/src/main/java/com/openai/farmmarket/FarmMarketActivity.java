package com.openai.farmmarket;

import android.app.NativeActivity;
import android.os.Bundle;
import android.view.View;

/** NativeActivity bootstrap for the C++/Raylib game. */
public final class FarmMarketActivity extends NativeActivity {
    static {
        System.loadLibrary("farmmarket");
    }

    private static native void nativeSetSavePath(String path);

    @Override
    protected void onCreate(Bundle state) {
        // Set the writable private save location before NativeActivity starts
        // the native game thread in super.onCreate().
        nativeSetSavePath(getFilesDir().getAbsolutePath() + "/farm_market_save.dat");
        super.onCreate(state);
        enableImmersiveMode();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) enableImmersiveMode();
    }

    private void enableImmersiveMode() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );
    }
}
