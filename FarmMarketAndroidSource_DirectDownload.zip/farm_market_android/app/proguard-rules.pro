# NativeActivity and the JNI save-path callback must remain available.
-keep class com.openai.farmmarket.FarmMarketActivity { *; }
